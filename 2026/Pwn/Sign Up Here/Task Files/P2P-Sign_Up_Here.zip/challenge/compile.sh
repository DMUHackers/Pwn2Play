#!/bin/bash

gcc $(pwd)/chall.c -o $(pwd)/chall -fstack-protector -fPIE -pie -Wl,-z,relro,-z,now -z noexecstack
