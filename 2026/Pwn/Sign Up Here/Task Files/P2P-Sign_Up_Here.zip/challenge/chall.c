#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct Player {
	char user_name[32];
	char user_email[32];
	char user_uni[32];
	int registered;
	int account_updated;
};

void clear_stdin() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void banner() {
	puts("╔════════════════════════════════════╗");
	puts("║              PWN2PLAY              ║");
	puts("║     Player Account Registration    ║");
	puts("╚════════════════════════════════════╝\n");
}

void read_line(char *buf, size_t max) {
	if (fgets(buf, max, stdin) == NULL) {
		exit(1);
	}
	buf[strcspn(buf, "\n")] = 0;
}

void register_account(struct Player *p) {
	if (p->registered == 1) {
		printf("\n[!] Account is Already Registered...\n");
	} else {
		puts("\n╔════════════════════════════════════╗");
		puts("║          Register Account          ║");
		puts("╚════════════════════════════════════╝");

		printf("\n[?] Player Username: ");
		read_line(p->user_name, sizeof(p->user_name));

		printf("[?] University Email: ");
		read_line(p->user_email, sizeof(p->user_email));

		printf("[?] University Name: ");
		read_line(p->user_uni, sizeof(p->user_uni));

		p->registered = 1;

		printf("\n[*] Account Registered Successfully.\n");
	}
}

void update_account_details(struct Player *p) {
	if (p->registered != 1) {
		printf("\n[!] No Registered Account...\n");
	} else {
		puts("\n╔════════════════════════════════════╗");
		puts("║           Update Account           ║");
		puts("╚════════════════════════════════════╝");

		char new_user_name[32];
		char new_user_email[32];
		char new_user_uni[32];

		printf("\n[?] Update Player Username: ");
		read_line(new_user_name, sizeof(new_user_name));
		if (new_user_name[0] != '\0') {
			strncpy(p->user_name, new_user_name, sizeof(p->user_name));
		}

		printf("[?] Update University Email: ");
		read_line(new_user_email, sizeof(new_user_email));
		if (new_user_email[0] != '\0') {
			strncpy(p->user_email, new_user_email, sizeof(p->user_email));
		}

		printf("[?] Update University Name: ");
		read_line(new_user_uni, sizeof(new_user_uni));
		if (new_user_uni[0] != '\0') {
			strncpy(p->user_uni, new_user_uni, sizeof(p->user_uni));
		}

		p->account_updated++;
		printf("\n[*] Account Details Updated Successfully.\n");
	}
}

void view_current_profile(const struct Player *p) {
	if (p->registered != 1) {
		printf("\n[!] No Registered Account...\n");
	} else {
		puts("\n╔════════════════════════════════════╗");
		puts("║           My P2P Profile           ║");
		puts("╚════════════════════════════════════╝");
		printf("My Username: %s\n", p->user_name);
		printf("My Email: %s\n", p->user_email);
		printf("My University: %s\n", p->user_uni);
	}
}

int admin_check_password(const char *password) {
	int obf_password[] = {114688, 71680, 114688, 64512, 93184, 143360, 110387, 150528, 111820, 136192, 97484, 144793, 140492, 167731, 147660, 47308, 60211};

	if (strlen(password) != 17) {
        return 1;
    }

    for (int i = 0; i < 17; i++) {
        int transformed = ((password[i] << 9) * 14) / 5;
        if (transformed != obf_password[i]) {
            return 1;
        }
    }
    return 0;
}

int admin_login() {
	char admin_password_input[18];

    printf("\n[?] Admin Debug Password: ");
	read_line(admin_password_input, sizeof(admin_password_input));
	clear_stdin();

    if (admin_check_password(admin_password_input) != 0) {
		return 1;
	} else {
		return 0;
	}
}

int admin_debug_menu(const struct Player *p) {
	puts("\n╔════════════════════════════════════╗");
	puts("║     Admin User Profile Details     ║");
	puts("╚════════════════════════════════════╝");

	if (p->registered != 1) {
		printf("\n[!] No Account Registered\n");
	} else {
		char formatted_data[256];
		snprintf(formatted_data, sizeof(formatted_data),
			"Current Registered Username: %s\nCurrent Registered User Email: %s\nCurrent Registered User University: %s\nNumber of Account Modifications: %i\n",
			p->user_name, p->user_email, p->user_uni, p->account_updated);

		char output[256];
		sprintf(output, formatted_data);

		printf("%s\n\n", output);
	}

	puts("\n╔════════════════════════════════════╗");
	puts("║          Admin Debug Menu          ║");
	puts("╚════════════════════════════════════╝");

	puts("[1] Report a Player");
	puts("[2] Submit a Bug Report");
	puts("[0] Back to Main Menu");
	printf("> ");

	char admin_choice[16];
	read_line(admin_choice, sizeof(admin_choice));

	if (strcmp(admin_choice, "1") == 0) {
		puts("\n╔════════════════════════════════════╗");
		puts("║         Admin Player Report        ║");
		puts("╚════════════════════════════════════╝");

		char report_player_name[32];
		char report_player_content[64];

		printf("\n[REPORT] Player's Username: ");
		read_line(report_player_name, sizeof(report_player_name));

		printf("[REPORT] Short Reason for Report: ");
		fgets(report_player_content, 512, stdin);

	}
	else if (strcmp(admin_choice, "2") == 0) {
		puts("\n╔════════════════════════════════════╗");
		puts("║          Admin Bug Report          ║");
		puts("╚════════════════════════════════════╝");

		char bug_report_title[16];
		char bug_report_content[64];

		printf("\n[BUG] Bug Report Title: ");
		read_line(bug_report_title, sizeof(bug_report_title));

		printf("[BUG] Bug Report Description: ");
		read_line(bug_report_content, sizeof(bug_report_content));

		printf("\n[*] Bug Reported Successfully!\n");
	}
	else if (strcmp(admin_choice, "0") == 0) {
		printf("\n[~] Returning to Main Menu...\n\n");
		return 0;
	}
	else {
		printf("\n[!] Invalid Option!\n");
		exit(0);
	}
	return 0;
}

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin,  NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	banner();

	struct Player current_player = {{0}, {0}, {0}, 0, 0};

	while (1) {
		puts("\n[1] Register an Account");
		puts("[2] Update Account Details");
		puts("[3] View Current Profile");
		puts("[0] Exit");
		printf("> ");

		char choice[16];
		read_line(choice, sizeof(choice));

		if (strcmp(choice, "1") == 0) {
			register_account(&current_player);
		}
		else if (strcmp(choice, "2") == 0) {
			update_account_details(&current_player);
		}
		else if (strcmp(choice, "3") == 0) {
			view_current_profile(&current_player);
		}
		else if (strcmp(choice, "DEBUG") == 0) {
			if (admin_login() != 0) {
				printf("\nIncorrect Password!\n");
				exit(0);
			} else {
				admin_debug_menu(&current_player);
			}
		}
		else if (strcmp(choice, "0") == 0) {
			printf("\n[+] Exiting...\n");
			exit(0);
		}
		else {
			printf("\n[!] Invalid Option...\n");
			exit(0);
		}

	}
	return 0;
}
