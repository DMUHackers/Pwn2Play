section .text
global _start

; Look how good i am at writing assembly :)

setup:
	mov rdi, 0
	mov rdx, 1000
	push 0
	pop rax
	ret

interact:
	call setup
	mov rsi, rsp
	sub rsi, 200
	syscall
	ret

_start:
	call interact

	mov rax, 60
	mov rdi, 0
	syscall

section .bss
    data: resb 500

section .note.GNU-stack noalloc noexec nowrite progbits
