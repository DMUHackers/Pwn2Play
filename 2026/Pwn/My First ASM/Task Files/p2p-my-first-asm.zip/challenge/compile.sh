#!/bin/bash

# Assemble
nasm -f elf64 -o chall.o chall.asm

# Link
ld -m elf_x86_64 -s -o chall chall.o

# Remove chall.o
rm chall.o
