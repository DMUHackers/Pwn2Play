#include <stdio.h>
#include <stdlib.h>

void win() {
	system("/bin/sh");
}

void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void greet() {
	char name[64];
	printf("Tell me your name: ");
	fgets(name, sizeof(name), stdin);

	char formatted[96];
	snprintf(formatted, sizeof(formatted), name);

	puts("\nThanks. You can leave now.\n");
}

int main() {
	setup();

	puts("This is literally the most boring binary you will see this CTF...\n");

	greet();

	puts("Told you it was boring.");
	return 0;
}
