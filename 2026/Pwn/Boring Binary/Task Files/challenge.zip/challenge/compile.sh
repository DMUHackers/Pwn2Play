#!/bin/bash

gcc -o chall chall.c -no-pie -fstack-protector-strong -Wl,-z,relro -z noexecstack
