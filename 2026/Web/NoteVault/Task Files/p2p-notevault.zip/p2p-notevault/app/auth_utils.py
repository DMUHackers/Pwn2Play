from flask import session, redirect, url_for, abort, request
from functools import wraps
from time import time
from db import get_user_role

# New auth funcs
def build_token(username):
    token = f"username:{username};timestamp:{str(int(time()))}"
    return token

def parse_token(token):
    try:
        token_data = [token_chunk.split(":") for token_chunk in token.split(";")]
        return dict(token_data)
    
    except Exception:
        return None

def is_admin_token(token):
    token_data = parse_token(token)
    if not token_data:
        return False
    
    try:
        user_role = get_user_role(token_data["username"])[0]
        if user_role == "administrator":
            return True
        return False
    
    except Exception:
        return False

def isLoggedIn(func):
    @wraps(func)
    def check_token(*args, **kwargs):
        if session.get("token", default=False) and session.get("id", default=False):
            return func(*args, **kwargs)
        
        else:
            return redirect(url_for("web.index"))
    
    return check_token

def isAdmin(func):
    @wraps(func)
    def is_admin(*args, **kwargs):
        if session.get("token", default=False) and is_admin_token(session.get("token", default=None)):
            return func(*args, **kwargs)
        
        else:
            return abort(403)
    
    return is_admin