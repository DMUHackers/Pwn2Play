from utils import get_secret_key

class Config(object):
    SECRET_KEY = get_secret_key()