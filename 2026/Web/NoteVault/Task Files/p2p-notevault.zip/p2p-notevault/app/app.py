from flask import Flask, render_template
from blueprints.web_routes import web
from blueprints.auth_routes import auth
from blueprints.admin_routes import admin

app = Flask(__name__, template_folder='templates', static_folder='static')
app.config.from_object('config.Config')

app.register_blueprint(web, url_prefix='/')
app.register_blueprint(auth, url_prefix='/auth')
app.register_blueprint(admin, url_prefix='/admin')

### Error Handling Route ###
@app.errorhandler(Exception)
def handle_errors(error):
    error_messages = {
        400: "Bad Request",
        403: "Access Forbidden",
        404: "Page Could Not Be Found",
        405: "Method Not Allowed",
        500: "Internal Server Error"
        }

    code = getattr(error, 'code', 400)
    message = error_messages.get(code, "Unexpected Error")
    return render_template("error.html", error_code=code, error_message=message), code
