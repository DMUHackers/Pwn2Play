import sqlite3
from contextlib import contextmanager
from utils import hash_password, generate_note_id

DB_PATH = "database/notevault.db"

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

class Database:
    def fetch_one(self, query, params=()):
        with get_db() as conn:
            return conn.execute(query, params).fetchone()

    def fetch_all(self, query, params=()):
        with get_db() as conn:
            return conn.execute(query, params).fetchall()

    def execute(self, query, params=()):
        with get_db() as conn:
            cur = conn.execute(query, params)
            return cur.lastrowid

db = Database()

def add_user(username, password):
    password_hash = hash_password(password)
    db.execute("INSERT INTO users(username, password, role) VALUES (?, ?, ?);", (username, password_hash, "user"))

def user_exists(username):
    exists = db.fetch_one("SELECT 1 FROM users WHERE username = ? LIMIT 1;", (username,)) is not None
    return exists

def check_creds(username, password):
    password_hash = hash_password(password)
    row = db.fetch_one("SELECT username, password FROM users WHERE username = ?;", (username,))
    if not row:
        return False
        
    if password_hash != row[1]:
        return False

    return True

def get_user_id(username):
    row = db.fetch_one("SELECT id FROM users WHERE username = ?;", (username,))
    return row

def get_user_role(username):
    row = db.fetch_one("SELECT role FROM users WHERE username = ?;", (username,))
    return row

def add_note(user_id, title, content):
    if not user_id:
        return None

    last_row = db.execute("INSERT INTO notes(noteId, userId, title, content) VALUES ('temp', ?, ?, ?);", (user_id, title, content))
    note_id_hash = generate_note_id(str(last_row))
    db.execute("UPDATE notes SET noteId = ? WHERE id = ?;", (note_id_hash, last_row,))

def get_note_content(note_id):
    return db.fetch_one("SELECT users.username, notes.title, notes.content FROM notes JOIN users ON notes.userId = users.id WHERE notes.noteId = ? LIMIT 1;", (note_id,))

def get_user_notes(user_id):
    if not user_id:
        None

    return db.fetch_all("SELECT noteId, title FROM notes WHERE userId = ?;", (user_id,))