from flask import Blueprint, render_template, redirect, url_for, session, request, flash, get_flashed_messages
from db import user_exists, add_user, check_creds, get_user_id
from auth_utils import build_token
from string import punctuation, whitespace

auth = Blueprint('auth', __name__, template_folder="templates", static_folder="static")

@auth.route("/login", methods=["GET", "POST"])
def login():
    # Check if user is already logged in
    if session.get("token", default=False) and session.get("id", default=False):
        return redirect(url_for("web.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", default="").strip()
        password = request.form.get("password", default="").strip()

        if not username or not password:
            flash("Missing Username or Password", "error")
            return redirect(request.url)
        
        if not check_creds(username, password):
            flash("Invalid Credentials", "error")
            return redirect(request.url)
        
        else:
            session["token"] = build_token(username)
            session["id"] = get_user_id(username)[0]
            flash("Login Successful", "success")
            return redirect(url_for("web.dashboard"))

    else:
        return render_template("login.html")

@auth.route("/register", methods=["GET", "POST"])
def register():
    # Check if user is already logged in
    if session.get("token", default=False) and session.get("id", default=False):
        return redirect(url_for("web.dashboard"))
        
    if request.method == "POST":
        username = request.form.get("username", default="").strip()
        password = request.form.get("password", default="").strip()

        if not username or not password:
            flash("Missing Username or Password", "error")
            return redirect(request.url)

        if user_exists(username):
            flash("User Already Exists", "error")
            return redirect(request.url)

        if any(username.startswith(bad_char) for bad_char in list(punctuation + whitespace)):
            flash("Username Cannot Begin With Special Characters", "error")
            return redirect(request.url)
        
        add_user(username, password)
        flash("Account Created", "success")
        return redirect(url_for("auth.login"))

    else:
        return render_template("register.html")

@auth.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Successfully Logged Out", "success")
    return redirect(url_for("web.index"))