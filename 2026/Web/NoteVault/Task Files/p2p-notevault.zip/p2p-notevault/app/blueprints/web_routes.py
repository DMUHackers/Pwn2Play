from flask import Blueprint, render_template, redirect, url_for, session, request, flash, get_flashed_messages
from db import add_note, get_user_notes, get_note_content
from auth_utils import isLoggedIn

web = Blueprint('web', __name__, template_folder="templates", static_folder="static")

@web.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@web.route("/dashboard", methods=["GET", "POST"])
@isLoggedIn
def dashboard():
    if request.method == "POST":
        note_title = request.form.get("title", default="").strip()
        note_content = request.form.get("content", default="").strip()

        if not note_title or not note_content:
            flash("Missing Note Title or Content", "error")
            return redirect(request.url)
        
        add_note(session.get("id", default=None), note_title, note_content)
        return redirect(request.url)

    else:
        notes = get_user_notes(session.get("id", default=None))
        return render_template("dashboard.html", notes=notes)

@web.route("/note/<note_id>", methods=["GET"])
@isLoggedIn
def read_note(note_id):
    note_content = get_note_content(note_id)
    return render_template("note.html", note_contents=note_content)