from flask import Blueprint, render_template, redirect, url_for, session, request, flash
from os import getenv
from auth_utils import isAdmin

admin = Blueprint('admin', __name__, template_folder="templates", static_folder="static")

@admin.route("/dashboard", methods=["GET"])
@isAdmin
def admin_dashboard():
    flag = getenv("FLAG") or "Could Not Get Flag. Please Inform an Event Organiser."
    return render_template("admin_dashboard.html", flag=flag)