from hashlib import sha3_512, md5
from dotenv import load_dotenv
from os import getenv

def get_secret_key():
    load_dotenv()
    return getenv("FLASK_SECRET_KEY")

# Function to hash a given password (string) using the SHA3_512 algorithm
def hash_password(password):
    hashed_password = sha3_512(password.encode()).hexdigest()
    return hashed_password

def generate_note_id(note_index):
    return md5(note_index.encode()).hexdigest()