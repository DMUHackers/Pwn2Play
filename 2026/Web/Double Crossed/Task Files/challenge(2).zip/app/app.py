from flask import Flask, abort, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_user, logout_user, login_required, current_user
from flask.cli import with_appcontext
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from functools import wraps
from lxml import etree
import re
from markupsafe import Markup, escape
from threading import Thread
from bot import run_moderation_bot


app = Flask(__name__)

# Config
app.config["SECRET_KEY"] = os.environ.get("SECRET")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///dbx.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = "static/uploads"
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return(url_for("login"))
        if not current_user.is_admin:
            abort(403)
        
        return f(*args, **kwargs)
    return decorated_function

def get_user_ip():
    # Handle proxy traffic (future proofing)
    if "X-Forwarded-For" in request.headers:
        return request.headers["X-Forwarded-For"]
    return request.remote_addr


def local_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if get_user_ip() != "127.0.0.1":
            abort(403)
        else:
            return f(*args, **kwargs)
    return decorated_function

@app.context_processor
def inject_ip():
    return dict(current_ip=get_user_ip())


def linkify(text):
    url_pattern = re.compile(r"(https?://[^\s]+)")

    def replace(match):
        url = match.group(0)
        return f'<a href="{escape(url)}" target="_blank" rel="noopener noreferrer">{escape(url)}</a>'

    linked_text = url_pattern.sub(replace, escape(text))
    return Markup(linked_text)

app.jinja_env.globals.update(linkify=linkify)

@app.cli.command("create-db")
@with_appcontext
def create_db():
    db.create_all()

    admin = User(username="admin", email="admin@p2p.dmu", is_admin=True)
    admin.set_password(os.environ.get("ADMIN_PASSWORD"))

    db.session.add(admin)
    db.session.commit()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    
    password_hash = db.Column(db.String(255), nullable=False)
    
    profile_image = db.Column(db.String(255), default="default.png")

    is_admin = db.Column(db.Boolean, default=False)


    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    posts = db.relationship("Post", backref="author", lazy=True)
    comments = db.relationship("Comment", backref="author", lazy=True)


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f"<User {self.username}>"


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)

    content = db.Column(db.Text, nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    likes = db.Column(db.Integer, default=0)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    comments = db.relationship("Comment", backref="post", cascade="all, delete", lazy=True)


    def __repr__(self):
        return f"<Post {self.id}>"


class Comment(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)

    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Foreign Keys
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)

class ManualReview(db.Model):
    __tablename__ = "manual_reviews"
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    reason = db.Column(db.String(255), default="Reported")
    status = db.Column(db.String(20), default="pending") 
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@app.route("/")
def index():
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return render_template("index.html", posts=posts)

@app.route("/profile/<username>")
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    return render_template("profile.html", user=user)

@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if request.method == "POST":
        if request.form.get("new_password"):
            new_password = request.form.get("new_password")
            confirm_password = request.form.get("confirm_password")

            if new_password != confirm_password:
                return "Passwords do not match"

            current_user.set_password(new_password)

        if "profile_image" in request.files:
            file = request.files["profile_image"]

            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)

                extension = filename.rsplit(".", 1)[1]
                new_filename = f"user_{current_user.id}.{extension}"

                file_path = os.path.join(app.config["UPLOAD_FOLDER"], new_filename)
                file.save(file_path)

                current_user.profile_image = new_filename
        db.session.commit()

        return redirect(url_for("profile", username=current_user.username))

    return render_template("settings.html")

@app.route("/create-post", methods=["POST"])
@login_required
def create_post():
    content = request.form.get("content")

    if not content or content.strip() == "":
        return redirect(url_for("index"))
    
    post = Post(content=content.strip(), author=current_user)

    db.session.add(post)
    db.session.commit()

    return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def admin_dashboard():
    users = User.query.all()
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return render_template("admin_dashboard.html", users=users, posts=posts)


@app.route("/admin/upload_users", methods=["POST"])
@admin_required
def admin_upload_users():
    if "userfile" not in request.files:
        return "No files", 400
    
    file = request.files.get("userfile")

    if file.filename == "":
        return "No selected file", 400

    filename = secure_filename(file.filename)
    if not filename.endswith(".xml"):
        return "Invalid file type", 400


    try:
        parser = etree.XMLParser(
            resolve_entities=True,
            load_dtd=True
        )

        tree = etree.parse(file, parser)
        root = tree.getroot()

        created_count = 0
        skipped_count = 0

        for user_elem in root.findall("user"):
            username_elem = user_elem.find("username")
            email_elem = user_elem.find("email")
            password_elem = user_elem.find("password")

            username = username_elem.text if username_elem is not None else None
            email = email_elem.text if email_elem is not None else None
            password = password_elem.text if password_elem is not None else None

            if not username or not email or not password:
                skipped_count += 1
                continue

            existing_user = User.query.filter(
                (User.username == username.strip()) |
                (User.email == email.strip())
            ).first()

            if existing_user:
                skipped_count += 1
                continue

            new_user = User(
                username=username.strip(),
                email=email.strip()
            )
            new_user.set_password(password.strip())

            db.session.add(new_user)
            created_count += 1

        db.session.commit()

        return f"Created {created_count} users, skipped {skipped_count}<br><a href='/admin'>Return to Admin</a>", 200

    except etree.XMLSyntaxError as e:
        print(e)
        return "Invalid XML file", 400


@app.route("/report/<int:post_id>", methods=["POST"])
@login_required
def report_post(post_id):
    post = Post.query.get_or_404(post_id)

    review = ManualReview(post_id=post_id)

    db.session.add(review)
    db.session.commit()

    Thread(target=run_moderation_bot, args=(post.id,)).start()

    return redirect(url_for("index"))



@app.route("/comment/<int:post_id>", methods=["POST"])
@login_required
def create_comment(post_id):
    content = request.form.get("content")
    comment = Comment(content=content, author=current_user, post_id=post_id)

    db.session.add(comment)
    db.session.commit()

    return redirect(url_for("index"))


@app.route("/register", methods=["GET", "POST"])
@local_required
def register():
    if request.method == "POST":
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")

        user = User(username=username, email=email)
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        login_user(user)
        return redirect(url_for("index"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for("index"))

        return "Invalid username or password"
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.errorhandler(403)
def forbidden(e):
    return render_template("403.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=3000)