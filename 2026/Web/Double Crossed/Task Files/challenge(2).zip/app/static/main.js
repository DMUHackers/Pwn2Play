function likePost(button) {
    const span = button.querySelector("span");
    let count = parseInt(span.innerText);
    span.innerText = count + 1;
}