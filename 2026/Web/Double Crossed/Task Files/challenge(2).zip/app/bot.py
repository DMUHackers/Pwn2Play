from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException, NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service   
from webdriver_manager.chrome import ChromeDriverManager

import re, os

def setup_browser():
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.binary_location = "/usr/bin/chromium"
    service = Service(ChromeDriverManager(chrome_type='chromium').install())
    browser = webdriver.Chrome(service=service, options=chrome_options)
    return browser

def run_moderation_bot(post_id):
    from app import db, Post, app
    with app.app_context():
        base_url = os.environ.get("BASE_URL")
        post = Post.query.get(post_id)
        if not post:
            return

        urls = re.findall(r'(https?://[^\s]+)', post.content)
        browser = setup_browser()

        try:
            browser.get(f"{base_url}/login")

            username_input = browser.find_element(By.NAME, "email")
            password_input = browser.find_element(By.NAME, "password")

            username_input.send_keys(os.environ.get("ADMIN_EMAIL"))
            password_input.send_keys(os.environ.get("ADMIN_PASSWORD"))
            password_input.send_keys(Keys.RETURN)

            browser.implicitly_wait(2)
        except NoSuchElementException:
            print("login not found, aborting...")
            browser.quit()
            return

        link_results = []

        for url in urls:
            try:
                browser.set_page_load_timeout(5)
                browser.get(url)
                link_results.append(f"Visited: {url}")
                print(f"Visted: {url}")
            except WebDriverException as e:
                link_results.append(f"Failed: {url} ({str(e)})")

        browser.quit()


