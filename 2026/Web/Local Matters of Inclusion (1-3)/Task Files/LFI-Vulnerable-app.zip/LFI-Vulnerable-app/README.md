
## Build the Image

```
docker build -t dmu-php-app .
```

## Run the Image

```
docker run --rm -p 8000:80 dmu-php-app
```

Exposes the webserver on http://localhost:8000