<?php
/**
 * DMU LOL Mart — Standalone PHP e-commerce mockup (single file)
 * - Session cart
 * - Catalog browse + search + category + sort
 * - Cart sidebar + mock checkout (no real payments)
 * - References a few external images (Unsplash hotlinks) with inline-SVG fallback
 *
 * Run locally:
 *   php -S localhost:8080
 *   open http://localhost:8080
 */

declare(strict_types=1);
session_start();

/* -----------------------------
   Mock catalog
   ----------------------------- */
$products = [
  [
    'id' => 'dmu-hoodie-404',
    'name' => 'DMU Hoodie: “404 Lecture Not Found”',
    'price' => 39.99,
    'category' => 'Apparel',
    'badge' => 'Best Seller',
    'image' => 'hoodie', // SVG fallback key
    'image_url' => '/images.php?img=/var/www/html/404hoodie.png', // hoodie-ish lifestyle
    'desc' => 'Premium hoodie for those days your timetable feels… fictional.',
    'tags' => ['hoodie', 'lecture', '404', 'timetable', 'funny'],
  ],
  [
    'id' => 'dmu-mug-latebus',
    'name' => 'Mug: “Powered by Caffeine & Late Buses”',
    'price' => 12.95,
    'category' => 'Drinkware',
    'badge' => 'New',
    'image' => 'mug',
    'image_url' => '/images.php?img=/var/www/html/mug.png', // mug mockup
    'desc' => 'Ceramic mug engineered for early starts and optimistic commutes.',
    'tags' => ['mug', 'caffeine', 'bus', 'morning', 'funny'],
  ],
  [
    'id' => 'dmu-tee-ctrlz',
    'name' => 'T-Shirt: “CTRL+Z My Deadline”',
    'price' => 18.50,
    'category' => 'Apparel',
    'badge' => '',
    'image' => 'tshirt',
    'image_url' => '/images.php?img=/var/www/html/tshirt.png', // tee / clothing vibe
    'desc' => 'Soft tee with a universally accepted academic shortcut (in spirit).',
    'tags' => ['tshirt', 'deadline', 'ctrlz', 'student', 'funny'],
  ],
  [
    'id' => 'dmu-tote-lanyard',
    'name' => 'Tote Bag: “I Have a Lanyard, Therefore I Am”',
    'price' => 14.75,
    'category' => 'Accessories',
    'badge' => '',
    'image' => 'tote',
    'image_url' => '/images.php?img=/var/www/html/tote.png', // tote / bag vibe
    'desc' => 'Carry your essentials and your existential student ID energy.',
    'tags' => ['tote', 'lanyard', 'id', 'bag', 'funny'],
  ],
  [
    'id' => 'dmu-stickers-seminar',
    'name' => 'Sticker Pack: “Seminar Survival Kit”',
    'price' => 6.99,
    'category' => 'Stationery',
    'badge' => 'Limited',
    'image' => 'stickers',
    'image_url' => '/images.php?img=/var/www/html/stickers.png', // desk / stationery vibe
    'desc' => 'Assorted stickers: “Group Work Veteran”, “Mute Button Hero”, and more.',
    'tags' => ['stickers', 'seminar', 'group work', 'stationery', 'funny'],
  ],
  [
    'id' => 'dmu-cap-lostcampus',
    'name' => 'Cap: “I’m Not Lost, I’m Exploring Campus”',
    'price' => 16.00,
    'category' => 'Apparel',
    'badge' => '',
    'image' => 'cap',
    'image_url' => '/images.php?img=/var/www/html/cap.png', // cap vibe
    'desc' => 'Adjustable cap for your scenic detours between buildings.',
    'tags' => ['cap', 'lost', 'campus', 'exploring', 'funny'],
  ],
  [
    'id' => 'dmu-notebook-assignment',
    'name' => 'Notebook: “Definitely Started This Early”',
    'price' => 9.50,
    'category' => 'Stationery',
    'badge' => '',
    'image' => 'notebook',
    'image_url' => '/images.php?img=/var/www/html/notebook.png', // notebook vibe
    'desc' => 'A5 notebook with a cover that tells the truth (professionally).',
    'tags' => ['notebook', 'assignment', 'early', 'notes', 'funny'],
  ],
  [
    'id' => 'dmu-socks-revision',
    'name' => 'Socks: “Revision? I Thought You Said Re-Vision”',
    'price' => 8.25,
    'category' => 'Apparel',
    'badge' => '',
    'image' => 'socks',
    'image_url' => '/images.php?img=/var/www/html/socks.png', // socks / fashion vibe
    'desc' => 'Comfort socks for turning panic into performance (allegedly).',
    'tags' => ['socks', 'revision', 'exam', 'comfort', 'funny'],
  ],
];

/* -----------------------------
   Helpers
   ----------------------------- */
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function money(float $n): string { return '£' . number_format($n, 2); }

function getProductById(array $products, string $id): ?array {
  foreach ($products as $p) if ($p['id'] === $id) return $p;
  return null;
}

function cartInit(): void {
  if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) $_SESSION['cart'] = [];
}

function cartAdd(string $id, int $qty = 1): void {
  cartInit();
  $qty = max(1, min(99, $qty));
  $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
  if ($_SESSION['cart'][$id] > 99) $_SESSION['cart'][$id] = 99;
}

function cartSet(string $id, int $qty): void {
  cartInit();
  $qty = (int)$qty;
  if ($qty <= 0) { unset($_SESSION['cart'][$id]); return; }
  $_SESSION['cart'][$id] = max(1, min(99, $qty));
}

function cartRemove(string $id): void { cartInit(); unset($_SESSION['cart'][$id]); }
function cartClear(): void { $_SESSION['cart'] = []; }

function cartCountItems(): int {
  cartInit();
  $c = 0; foreach ($_SESSION['cart'] as $q) $c += (int)$q;
  return $c;
}

function cartSubtotal(array $products): float {
  cartInit();
  $sum = 0.0;
  foreach ($_SESSION['cart'] as $id => $qty) {
    $p = getProductById($products, (string)$id);
    if ($p) $sum += ((float)$p['price']) * ((int)$qty);
  }
  return $sum;
}

function shippingCost(float $postDiscountSubtotal): float {
  if ($postDiscountSubtotal <= 0.0) return 0.0;
  if ($postDiscountSubtotal >= 50.0) return 0.0;
  return 3.95;
}

function applyDiscount(float $subtotal, string $code): array {
  $code = strtoupper(trim($code));
  if ($subtotal <= 0.0) return [0.0, ''];

  $discount = 0.0;
  $msg = '';
  if ($code === 'DMU10') {
    $discount = round($subtotal * 0.10, 2);
    $msg = 'Code DMU10 applied (10% off).';
  } elseif ($code === 'FRESHERS5') {
    $discount = min(5.00, $subtotal);
    $msg = 'Code FRESHERS5 applied (£5 off).';
  } elseif ($code !== '') {
    $msg = 'Code not recognised.';
  }
  return [$discount, $msg];
}

function buildQuery(array $overrides = []): string {
  $params = $_GET;
  foreach ($overrides as $k => $v) {
    if ($v === null) unset($params[$k]);
    else $params[$k] = $v;
  }
  $qs = http_build_query($params);
  return $qs ? ('?' . $qs) : '';
}

/* -----------------------------
   Inline SVG product placeholders
   ----------------------------- */
function productSvg(string $kind): string {
  $common = 'width="100%" height="100%" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"';
  if ($kind === 'hoodie') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M60 60c10-20 70-20 80 0l18 22v78c0 10-8 18-18 18H60c-10 0-18-8-18-18V82l18-22z' fill='currentColor' opacity='0.18'/><path d='M75 72c15 18 35 18 50 0' stroke='currentColor' stroke-width='8' fill='none' opacity='0.35'/><text x='100' y='150' text-anchor='middle' font-size='22' fill='currentColor' opacity='0.55'>404</text></svg>";
  if ($kind === 'mug') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M60 70h70v70c0 15-12 27-27 27H87c-15 0-27-12-27-27V70z' fill='currentColor' opacity='0.20'/><path d='M130 80h15c15 0 25 10 25 25s-10 25-25 25h-15' stroke='currentColor' stroke-width='10' fill='none' opacity='0.35'/><text x='95' y='125' text-anchor='middle' font-size='14' fill='currentColor' opacity='0.55'>CAFFEINE</text></svg>";
  if ($kind === 'tshirt') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M70 60l30-20 30 20 25 10-15 30v70H60v-70L45 70l25-10z' fill='currentColor' opacity='0.20'/><text x='100' y='125' text-anchor='middle' font-size='16' fill='currentColor' opacity='0.55'>CTRL+Z</text></svg>";
  if ($kind === 'tote') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M65 70h70l10 100H55L65 70z' fill='currentColor' opacity='0.20'/><path d='M80 70c0-18 40-18 40 0' stroke='currentColor' stroke-width='10' fill='none' opacity='0.35'/><text x='100' y='135' text-anchor='middle' font-size='14' fill='currentColor' opacity='0.55'>LANYARD</text></svg>";
  if ($kind === 'stickers') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><rect x='55' y='60' width='60' height='60' rx='12' fill='currentColor' opacity='0.20'/><rect x='95' y='85' width='60' height='60' rx='12' fill='currentColor' opacity='0.14'/><text x='100' y='155' text-anchor='middle' font-size='14' fill='currentColor' opacity='0.55'>PACK</text></svg>";
  if ($kind === 'cap') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M55 110c0-30 90-30 90 0v20H55v-20z' fill='currentColor' opacity='0.20'/><path d='M140 130c25 0 40 10 40 20s-15 20-40 20' fill='currentColor' opacity='0.12'/><text x='100' y='105' text-anchor='middle' font-size='14' fill='currentColor' opacity='0.55'>NOT LOST</text></svg>";
  if ($kind === 'notebook') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><rect x='60' y='55' width='90' height='120' rx='10' fill='currentColor' opacity='0.18'/><rect x='50' y='55' width='18' height='120' rx='8' fill='currentColor' opacity='0.25'/><text x='105' y='120' text-anchor='middle' font-size='12' fill='currentColor' opacity='0.55'>STARTED</text></svg>";
  if ($kind === 'socks') return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><path d='M80 55h45v70c0 18-15 33-33 33H70v-25h22c10 0 18-8 18-18V55z' fill='currentColor' opacity='0.20'/><text x='100' y='155' text-anchor='middle' font-size='14' fill='currentColor' opacity='0.55'>RE-VISION</text></svg>";
  return "<svg {$common}><rect x='20' y='30' width='160' height='140' rx='18' fill='currentColor' opacity='0.08'/><circle cx='100' cy='105' r='45' fill='currentColor' opacity='0.18'/></svg>";
}

/**
 * Render product media: external image first; fallback to inline SVG if image fails or missing.
 */
function productMedia(array $p): string {
  $alt = h($p['name'] ?? 'Product image');
  $fallbackSvg = productSvg((string)($p['image'] ?? ''));

  if (!empty($p['image_url'])) {
    $url = h((string)$p['image_url']);
    return '
      <div class="media" data-fallback-svg="'.h($fallbackSvg).'">
        <img class="media-img" src="'.$url.'" alt="'.$alt.'" loading="lazy"
             onerror="this.parentElement.innerHTML=this.parentElement.dataset.fallbackSvg;" />
      </div>
    ';
  }

  return '<div class="media media-svg">'.$fallbackSvg.'</div>';
}

/* -----------------------------
   Flash messaging
   ----------------------------- */
function flashSet(string $type, string $message): void {
  $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function flashGet(): ?array {
  if (!isset($_SESSION['flash'])) return null;
  $f = $_SESSION['flash'];
  unset($_SESSION['flash']);
  return is_array($f) ? $f : null;
}

/* -----------------------------
   CSRF token (simple)
   ----------------------------- */
if (!isset($_SESSION['token'])) $_SESSION['token'] = bin2hex(random_bytes(16));

/* -----------------------------
   Actions (POST)
   ----------------------------- */
cartInit();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = (string)($_POST['action'] ?? '');
  $token  = (string)($_POST['token'] ?? '');
  $redirect = (string)($_POST['redirect'] ?? ($_SERVER['REQUEST_URI'] ?? '/'));

  if (!hash_equals($_SESSION['token'], $token)) {
    flashSet('error', 'Request blocked (invalid token). Refresh and try again.');
    header('Location: ' . $redirect);
    exit;
  }

  switch ($action) {
    case 'add': {
      $id = (string)($_POST['id'] ?? '');
      $qty = (int)($_POST['qty'] ?? 1);
      if (getProductById($products, $id)) {
        cartAdd($id, $qty);
        flashSet('success', 'Added to cart.');
      } else {
        flashSet('error', 'Product not found.');
      }
      break;
    }
    case 'set_qty': {
      $id = (string)($_POST['id'] ?? '');
      $qty = (int)($_POST['qty'] ?? 1);
      if (getProductById($products, $id)) {
        cartSet($id, $qty);
        flashSet('success', 'Cart updated.');
      } else {
        flashSet('error', 'Product not found.');
      }
      break;
    }
    case 'remove': {
      $id = (string)($_POST['id'] ?? '');
      cartRemove($id);
      flashSet('success', 'Removed from cart.');
      break;
    }
    case 'clear': {
      cartClear();
      flashSet('success', 'Cart cleared.');
      break;
    }
    case 'checkout': {
      $name  = trim((string)($_POST['full_name'] ?? ''));
      $email = trim((string)($_POST['email'] ?? ''));
      $addr  = trim((string)($_POST['address'] ?? ''));
      $code  = trim((string)($_POST['discount_code'] ?? ''));

      $subtotal = cartSubtotal($products);
      [$discount, $discountMsg] = applyDiscount($subtotal, $code);
      $postDiscount = max(0.0, $subtotal - $discount);
      $ship = shippingCost($postDiscount);
      $total = max(0.0, $postDiscount + $ship);

      $errors = [];
      if ($subtotal <= 0.0) $errors[] = 'Your cart is empty.';
      if ($name === '') $errors[] = 'Full name is required.';
      if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
      if ($addr === '') $errors[] = 'Address is required.';

      if ($errors) {
        flashSet('error', 'Checkout failed: ' . implode(' ', $errors));
      } else {
        $orderId = 'DMU-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $_SESSION['last_order'] = [
          'order_id' => $orderId,
          'name' => $name,
          'email' => $email,
          'address' => $addr,
          'total' => $total,
          'items' => $_SESSION['cart'],
          'code' => $code,
          'discount' => $discount,
          'shipping' => $ship,
          'created_at' => date('Y-m-d H:i:s'),
        ];
        cartClear();
        $msg = "Order placed (mock). Confirmation: {$orderId}.";
        if ($discountMsg) $msg .= " {$discountMsg}";
        flashSet('success', $msg);
      }
      break;
    }
    default:
      flashSet('error', 'Unknown action.');
  }

  header('Location: ' . $redirect);
  exit;
}

/* -----------------------------
   Listing filters (GET)
   ----------------------------- */
$q = trim((string)($_GET['q'] ?? ''));
$cat = trim((string)($_GET['cat'] ?? ''));
$sort = (string)($_GET['sort'] ?? 'featured'); // featured | price_asc | price_desc | name_asc

$categories = array_values(array_unique(array_map(fn($p) => $p['category'], $products)));
sort($categories);

$filtered = array_values(array_filter($products, function($p) use ($q, $cat) {
  if ($cat !== '' && $p['category'] !== $cat) return false;
  if ($q === '') return true;
  $hay = strtolower($p['name'] . ' ' . $p['desc'] . ' ' . implode(' ', $p['tags']));
  return strpos($hay, strtolower($q)) !== false;
}));

usort($filtered, function($a, $b) use ($sort) {
  if ($sort === 'price_asc') return ($a['price'] <=> $b['price']);
  if ($sort === 'price_desc') return ($b['price'] <=> $a['price']);
  if ($sort === 'name_asc') return strcmp($a['name'], $b['name']);

  $rank = function($p) {
    $badge = $p['badge'] ?? '';
    if ($badge === 'Best Seller') return 0;
    if ($badge === 'New') return 1;
    if ($badge === 'Limited') return 2;
    return 3;
  };
  $ra = $rank($a); $rb = $rank($b);
  if ($ra !== $rb) return $ra <=> $rb;
  return strcmp($a['name'], $b['name']);
});

$cartCount = cartCountItems();
$subtotal = cartSubtotal($products);
$lastOrder = $_SESSION['last_order'] ?? null;
$flash = flashGet();

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>DMU LOL Mart — Funny DMU Merchandise (Mockup)</title>
  <style>
    :root{
      --bg: #0b1020;
      --panel: rgba(255,255,255,0.06);
      --panel2: rgba(255,255,255,0.09);
      --stroke: rgba(255,255,255,0.10);
      --text: rgba(255,255,255,0.92);
      --muted: rgba(255,255,255,0.68);
      --muted2: rgba(255,255,255,0.52);
      --ok: #7CFFB2;
      --warn: #FFD27C;
      --bad: #FF7C7C;
      --shadow: 0 18px 45px rgba(0,0,0,0.45);
      --r: 18px;
    }
    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
      background: radial-gradient(1200px 800px at 20% 10%, rgba(124,255,178,0.10), transparent 55%),
                  radial-gradient(900px 600px at 80% 30%, rgba(124,167,255,0.12), transparent 55%),
                  var(--bg);
      color:var(--text);
    }
    a{ color:inherit; text-decoration:none; }
    .container{ max-width:1180px; margin:0 auto; padding:28px 18px 72px; }

    /* Header */
    .topbar{
      position: sticky; top:0; z-index:10;
      background: rgba(11,16,32,0.80);
      backdrop-filter: blur(10px);
      border-bottom:1px solid var(--stroke);
    }
    .topbar-inner{
      max-width:1180px; margin:0 auto; padding:14px 18px;
      display:flex; align-items:center; justify-content:space-between; gap:12px;
    }
    .brand{ display:flex; align-items:center; gap:10px; }
    .logo{
      width:38px; height:38px; border-radius:12px;
      background: linear-gradient(135deg, rgba(124,255,178,0.25), rgba(124,167,255,0.25));
      border:1px solid var(--stroke);
      display:grid; place-items:center;
      font-weight:800;
    }
    .brand h1{ margin:0; font-size:16px; letter-spacing:0.2px; }
    .brand .sub{ margin:0; font-size:12px; color:var(--muted2); }

    .pill{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.05);
      padding:8px 12px;
      border-radius:999px;
      display:flex; gap:8px; align-items:center;
      color:var(--muted);
      font-size:13px;
    }
    .btn{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.06);
      color:var(--text);
      padding:10px 12px;
      border-radius:12px;
      cursor:pointer;
      font-size:13px;
      transition: transform .08s ease, background .15s ease;
    }
    .btn:hover{ background: rgba(255,255,255,0.10); }
    .btn:active{ transform: translateY(1px); }
    .btn.primary{
      background: linear-gradient(135deg, rgba(124,255,178,0.20), rgba(124,167,255,0.16));
      border-color: rgba(124,255,178,0.25);
    }
    .btn.danger{ border-color: rgba(255,124,124,0.35); }
    .cartBtn{
      display:flex; gap:10px; align-items:center;
      white-space:nowrap;
    }
    .badgeCount{
      min-width:22px;
      padding:2px 8px;
      border-radius:999px;
      background: rgba(124,255,178,0.16);
      border:1px solid rgba(124,255,178,0.24);
      text-align:center;
      font-weight:700;
      font-size:12px;
    }

    /* Hero */
    .hero{
      margin-top:22px;
      border:1px solid var(--stroke);
      background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.04));
      border-radius: var(--r);
      padding:22px;
      box-shadow: var(--shadow);
      display:grid;
      grid-template-columns: 1.4fr 1fr;
      gap:18px;
    }
    .hero h2{ margin:0 0 8px; font-size:26px; letter-spacing:-0.2px; }
    .hero p{ margin:0 0 14px; color:var(--muted); line-height:1.45; }
    .hero .notes{
      display:flex; gap:10px; flex-wrap:wrap;
    }
    .note{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.05);
      padding:8px 10px;
      border-radius:12px;
      color:var(--muted);
      font-size:12px;
    }
    .hero-card{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: var(--r);
      padding:14px;
      display:flex;
      flex-direction:column;
      gap:10px;
      justify-content:space-between;
    }
    .hero-card .kpi{
      display:grid;
      grid-template-columns: 1fr 1fr;
      gap:10px;
    }
    .k{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius:14px;
      padding:10px;
    }
    .k .label{ font-size:12px; color:var(--muted2); margin-bottom:6px; }
    .k .value{ font-size:18px; font-weight:800; }

    /* Filters */
    .filters{
      margin-top:18px;
      display:flex;
      gap:10px;
      flex-wrap:wrap;
      align-items:center;
      justify-content:space-between;
    }
    .filters form{
      display:flex; gap:10px; flex-wrap:wrap; align-items:center;
      width:100%;
    }
    .field{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: 14px;
      padding:10px 12px;
      color: var(--text);
      display:flex;
      align-items:center;
      gap:8px;
      flex: 1 1 260px;
      min-width: 220px;
    }
    .field input, .field select{
      width:100%;
      border:none;
      outline:none;
      background: transparent;
      color: var(--text);
      font-size:13px;
    }
    .field select option{ color:#111; }
    .small{ flex: 0 0 200px; min-width: 200px; }

    /* Grid */
    .grid{
      margin-top:16px;
      display:grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap:14px;
    }
    @media (max-width: 1040px){
      .hero{ grid-template-columns: 1fr; }
      .grid{ grid-template-columns: repeat(2, minmax(0,1fr)); }
    }
    @media (max-width: 560px){
      .grid{ grid-template-columns: 1fr; }
      .small{ flex: 1 1 200px; }
    }

    .card{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: var(--r);
      overflow:hidden;
      box-shadow: 0 10px 25px rgba(0,0,0,0.30);
      display:flex;
      flex-direction:column;
      min-height: 100%;
    }
    .card-body{
      padding:12px 12px 14px;
      display:flex;
      flex-direction:column;
      gap:10px;
      flex:1;
    }
    .title{ font-weight:800; letter-spacing:-0.1px; }
    .desc{ font-size:13px; color: var(--muted); line-height:1.35; min-height: 36px; }
    .row{ display:flex; justify-content:space-between; align-items:center; gap:10px; }
    .price{ font-weight:900; font-size:16px; }
    .tag{
      font-size:11px;
      color: var(--muted);
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      padding:4px 8px;
      border-radius: 999px;
    }
    .tag.emph{
      border-color: rgba(124,255,178,0.25);
      background: rgba(124,255,178,0.12);
      color: rgba(255,255,255,0.92);
      font-weight:700;
    }

    /* Media */
    .media{
      width:100%;
      aspect-ratio: 1 / 1;
      border-bottom:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .media-img{
      width:100%;
      height:100%;
      object-fit:cover;
      display:block;
      filter: saturate(1.05) contrast(1.02);
    }
    .media-svg svg{ width:100%; height:100%; }

    /* Cart sidebar */
    .overlay{
      position:fixed;
      inset:0;
      background: rgba(0,0,0,0.55);
      display:none;
      z-index:30;
    }
    .drawer{
      position:fixed;
      top:0; right:0;
      width: min(520px, 92vw);
      height:100%;
      background: rgba(11,16,32,0.92);
      backdrop-filter: blur(12px);
      border-left:1px solid var(--stroke);
      box-shadow: var(--shadow);
      transform: translateX(100%);
      transition: transform .18s ease;
      z-index:40;
      display:flex;
      flex-direction:column;
    }
    .drawer.open{ transform: translateX(0); }
    .overlay.open{ display:block; }
    .drawer-header{
      padding:16px 16px 12px;
      border-bottom:1px solid var(--stroke);
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
    }
    .drawer-header h3{ margin:0; font-size:15px; letter-spacing:0.2px; }
    .drawer-body{
      padding:12px 16px;
      overflow:auto;
      flex:1;
      display:flex;
      flex-direction:column;
      gap:12px;
    }
    .line{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: 16px;
      padding:10px;
      display:grid;
      grid-template-columns: 52px 1fr;
      gap:10px;
      align-items:start;
    }
    .thumb{
      width:52px; height:52px;
      border-radius: 14px;
      border:1px solid var(--stroke);
      overflow:hidden;
      background: rgba(255,255,255,0.04);
      display:flex; align-items:center; justify-content:center;
      color: rgba(255,255,255,0.85);
    }
    .thumb img{ width:100%; height:100%; object-fit:cover; display:block; }
    .thumb svg{ width:100%; height:100%; }
    .line .name{ font-weight:800; font-size:13px; margin:0 0 6px; }
    .line .meta{ display:flex; justify-content:space-between; align-items:center; gap:10px; }
    .qty{
      display:flex; gap:8px; align-items:center;
    }
    .qty input{
      width:58px;
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: 12px;
      padding:8px 10px;
      color: var(--text);
      outline:none;
    }
    .drawer-footer{
      padding:14px 16px;
      border-top:1px solid var(--stroke);
      display:flex;
      flex-direction:column;
      gap:10px;
    }
    .totals{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: 16px;
      padding:10px;
      color: var(--muted);
      font-size:13px;
    }
    .totals .trow{
      display:flex; justify-content:space-between; align-items:center;
      padding:6px 0;
      border-bottom:1px dashed rgba(255,255,255,0.10);
    }
    .totals .trow:last-child{ border-bottom:none; }
    .totals .big{ color: var(--text); font-weight:900; }

    /* Modal */
    .modalWrap{
      position:fixed;
      inset:0;
      display:none;
      align-items:center;
      justify-content:center;
      padding:18px;
      z-index:50;
    }
    .modalWrap.open{ display:flex; }
    .modal{
      width:min(640px, 96vw);
      border:1px solid var(--stroke);
      background: rgba(11,16,32,0.96);
      backdrop-filter: blur(12px);
      border-radius: 20px;
      box-shadow: var(--shadow);
      overflow:hidden;
    }
    .modal-head{
      padding:14px 16px;
      border-bottom:1px solid var(--stroke);
      display:flex; justify-content:space-between; align-items:center;
    }
    .modal-head h4{ margin:0; font-size:14px; }
    .modal-body{ padding:16px; display:grid; gap:12px; }
    .formGrid{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
    .formGrid .full{ grid-column: 1 / -1; }
    .input{
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.04);
      border-radius: 14px;
      padding:10px 12px;
      color: var(--text);
      outline:none;
      width:100%;
    }
    .modal-actions{
      padding:14px 16px;
      border-top:1px solid var(--stroke);
      display:flex;
      justify-content:flex-end;
      gap:10px;
      flex-wrap:wrap;
    }

    /* Toast */
    .toast{
      position: fixed;
      top: 68px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 60;
      max-width: min(720px, 92vw);
      border:1px solid var(--stroke);
      background: rgba(255,255,255,0.06);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: 12px 14px;
      box-shadow: var(--shadow);
      display:flex;
      align-items:flex-start;
      gap:10px;
      color: var(--text);
    }
    .dot{
      width:10px; height:10px; border-radius: 999px; margin-top:4px;
      background: rgba(124,167,255,0.85);
    }
    .toast.success .dot{ background: rgba(124,255,178,0.90); }
    .toast.error .dot{ background: rgba(255,124,124,0.90); }
    .toast .msg{ color: var(--muted); font-size:13px; line-height:1.35; }
    .foot{
      margin-top: 22px;
      color: var(--muted2);
      font-size: 12px;
      line-height: 1.45;
    }
    .hr{ height:1px; background: rgba(255,255,255,0.10); border:0; margin:18px 0 12px; }
  </style>
</head>

<body>
  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand">
        <div class="logo">DMU</div>
        <div>
          <h1>DMU LOL Mart</h1>
          <p class="sub">LOL-Cost Store</p>
        </div>
      </div>

      <div style="display:flex; gap:10px; align-items:center;">
        <button class="btn primary cartBtn" type="button" onclick="openCart()">
          <span>Cart</span>
          <span class="badgeCount"><?= (int)$cartCount ?></span>
        </button>
      </div>
    </div>
  </div>

  <?php if ($flash): ?>
    <div class="toast <?= h((string)$flash['type']) ?>" id="toast">
      <div class="dot"></div>
      <div>
        <div style="font-weight:800; font-size:13px; margin-bottom:2px;">
          <?= $flash['type']==='success' ? 'Success' : ($flash['type']==='error' ? 'Attention' : 'Notice') ?>
        </div>
        <div class="msg"><?= h((string)$flash['message']) ?></div>
      </div>
      <div style="margin-left:auto;">
        <button class="btn" type="button" onclick="closeToast()">Close</button>
      </div>
    </div>
  <?php endif; ?>

  <div class="container">
    <section class="hero">
      <div>
        <h2>Merch for people who “definitely started early”.</h2>
        <p>
          Whatcha Buying!
        </p>
        <div class="notes">
          <div class="note">Discount codes: <strong>DMU10</strong> or <strong>FRESHERS5</strong></div>
          <div class="note">Free shipping over <strong>£50</strong></div>
          <div class="note">Lore based merch</div>
        </div>

        <?php if (is_array($lastOrder) && !empty($lastOrder['order_id'])): ?>
          <hr class="hr"/>
          <div class="note" style="border-color: rgba(124,255,178,0.22); background: rgba(124,255,178,0.08);">
            Last mock order: <strong><?= h((string)$lastOrder['order_id']) ?></strong>
            • Total: <strong><?= money((float)$lastOrder['total']) ?></strong>
            • Created: <?= h((string)$lastOrder['created_at']) ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="hero-card">
        <div class="kpi">
          <div class="k">
            <div class="label">Cart subtotal</div>
            <div class="value"><?= money((float)$subtotal) ?></div>
          </div>
          <div class="k">
            <div class="label">Shipping</div>
            <div class="value"><?= $subtotal >= 50.0 ? '£0.00' : ($subtotal > 0.0 ? '£3.95' : '£0.00') ?></div>
          </div>
        </div>
        <div>
          <button class="btn primary" type="button" onclick="openCart()" style="width: 100%">Open cart</button>
        </div>
      </div>
    </section>

    <section class="filters">
      <form method="get" action="">
        <div class="field">
          <span style="opacity:.65;">Search</span>
          <input name="q" value="<?= h($q) ?>" placeholder="e.g., hoodie, deadline, caffeine, lanyard"/>
        </div>

        <div class="field small">
          <select name="cat" aria-label="Category">
            <option value="">All categories</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= h($c) ?>" <?= $cat===$c ? 'selected' : '' ?>><?= h($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="field small">
          <select name="sort" aria-label="Sort">
            <option value="featured" <?= $sort==='featured' ? 'selected' : '' ?>>Sort: Featured</option>
            <option value="price_asc" <?= $sort==='price_asc' ? 'selected' : '' ?>>Price: Low → High</option>
            <option value="price_desc" <?= $sort==='price_desc' ? 'selected' : '' ?>>Price: High → Low</option>
            <option value="name_asc" <?= $sort==='name_asc' ? 'selected' : '' ?>>Name: A → Z</option>
          </select>
        </div>

        <button class="btn" type="submit">Apply</button>
        <a class="btn" href="<?= h(buildQuery(['q'=>null,'cat'=>null,'sort'=>null])) ?>">Reset</a>
      </form>
    </section>

    <section class="grid" aria-label="Product grid">
      <?php if (!$filtered): ?>
        <div class="card" style="grid-column: 1 / -1;">
          <div class="card-body">
            <div class="title">No matches</div>
            <div class="desc">Try a different keyword, or clear filters.</div>
          </div>
        </div>
      <?php endif; ?>

      <?php foreach ($filtered as $p): ?>
        <article class="card">
          <?= productMedia($p) ?>
          <div class="card-body">
            <div class="row">
              <div class="title"><?= h($p['name']) ?></div>
            </div>
            <div class="desc"><?= h($p['desc']) ?></div>

            <div class="row">
              <div class="price"><?= money((float)$p['price']) ?></div>
              <div style="display:flex; gap:8px; align-items:center;">
                <?php if (!empty($p['badge'])): ?>
                  <span class="tag emph"><?= h($p['badge']) ?></span>
                <?php endif; ?>
                <span class="tag"><?= h($p['category']) ?></span>
              </div>
            </div>

            <form method="post" action="">
              <input type="hidden" name="token" value="<?= h($_SESSION['token']) ?>"/>
              <input type="hidden" name="action" value="add"/>
              <input type="hidden" name="id" value="<?= h($p['id']) ?>"/>
              <input type="hidden" name="redirect" value="<?= h($_SERVER['REQUEST_URI'] ?? '/') ?>"/>
              <div class="row">
                <div class="qty" style="gap:6px;">
                  <input name="qty" type="number" min="1" max="99" value="1" aria-label="Quantity"/>
                </div>
                <button class="btn primary" type="submit">Add to cart</button>
              </div>
            </form>
          </div>
        </article>
      <?php endforeach; ?>
    </section>

    <div class="foot">
      <hr class="hr"/>
      <div><strong>Disclaimer:</strong> This site isn't actually real believe it or not.</div>
    </div>
  </div>

  <!-- Cart Overlay + Drawer -->
  <div class="overlay" id="overlay" onclick="closeCart()"></div>

  <aside class="drawer" id="drawer" aria-label="Cart drawer">
    <div class="drawer-header">
      <h3>Your cart (<?= (int)$cartCount ?>)</h3>
      <div style="display:flex; gap:10px;">
        <button class="btn" type="button" onclick="closeCart()">Close</button>
      </div>
    </div>

    <div class="drawer-body">
      <?php if ($cartCount <= 0): ?>
        <div class="totals">
          <div class="trow"><span>Your cart is empty.</span><span class="big">£0.00</span></div>
          <div style="padding-top:6px; color: rgba(255,255,255,0.55);">
            Add something ridiculous from the grid and come back.
          </div>
        </div>
      <?php else: ?>
        <?php foreach ($_SESSION['cart'] as $id => $qty): ?>
          <?php $p = getProductById($products, (string)$id); if (!$p) continue; ?>
          <div class="line">
            <div class="thumb" aria-hidden="true">
              <?php if (!empty($p['image_url'])): ?>
                <img src="<?= h((string)$p['image_url']) ?>" alt="" loading="lazy"/>
              <?php else: ?>
                <?= productSvg((string)$p['image']) ?>
              <?php endif; ?>
            </div>
            <div>
              <p class="name"><?= h($p['name']) ?></p>
              <div class="meta">
                <div style="color: rgba(255,255,255,0.80); font-weight:900;"><?= money((float)$p['price']) ?></div>

                <div style="display:flex; gap:8px; align-items:center;">
                  QTY
                  <form method="post" action="" class="qty" style="margin:0;">
                    <input type="hidden" name="token" value="<?= h($_SESSION['token']) ?>"/>
                    <input type="hidden" name="action" value="set_qty"/>
                    <input type="hidden" name="id" value="<?= h((string)$p['id']) ?>"/>
                    <input type="hidden" name="redirect" value="<?= h($_SERVER['REQUEST_URI'] ?? '/') ?>"/>
                    <input name="qty" type="number" min="0" max="99" value="<?= (int)$qty ?>" aria-label="Quantity"/>
                    <button class="btn" type="submit">Update</button>
                  </form>

                  <form method="post" action="" style="margin:0;">
                    <input type="hidden" name="token" value="<?= h($_SESSION['token']) ?>"/>
                    <input type="hidden" name="action" value="remove"/>
                    <input type="hidden" name="id" value="<?= h((string)$p['id']) ?>"/>
                    <input type="hidden" name="redirect" value="<?= h($_SERVER['REQUEST_URI'] ?? '/') ?>"/>
                    <button class="btn danger" type="submit">Remove</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="drawer-footer">
      <?php
        $discountCodePreview = '';
        [$discPreview, $discMsgPreview] = applyDiscount($subtotal, $discountCodePreview);
        $postDiscountPreview = max(0.0, $subtotal - $discPreview);
        $shipPreview = shippingCost($postDiscountPreview);
        $totalPreview = max(0.0, $postDiscountPreview + $shipPreview);
      ?>
      <div class="totals">
        <div class="trow"><span>Subtotal</span><span class="big"><?= money((float)$subtotal) ?></span></div>
        <div class="trow"><span>Shipping</span><span class="big"><?= money((float)$shipPreview) ?></span></div>
        <div class="trow"><span>Total</span><span class="big"><?= money((float)$totalPreview) ?></span></div>
      </div>

      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <form method="post" action="" style="margin:0;">
          <input type="hidden" name="token" value="<?= h($_SESSION['token']) ?>"/>
          <input type="hidden" name="action" value="clear"/>
          <input type="hidden" name="redirect" value="<?= h($_SERVER['REQUEST_URI'] ?? '/') ?>"/>
          <button class="btn danger" type="submit" <?= $cartCount<=0 ? 'disabled' : '' ?>>Clear cart</button>
        </form>
        <button class="btn primary" type="button" onclick="openCheckout()" <?= $cartCount<=0 ? 'disabled' : '' ?>>
          Checkout (mock)
        </button>
      </div>
    </div>
  </aside>

  <!-- Checkout Modal -->
  <div class="modalWrap" id="checkoutWrap" aria-label="Checkout modal" role="dialog" aria-modal="true">
    <div class="modal">
      <div class="modal-head">
        <h4>Mock checkout</h4>
        <button class="btn" type="button" onclick="closeCheckout()">Close</button>
      </div>

      <form method="post" action="">
        <input type="hidden" name="token" value="<?= h($_SESSION['token']) ?>"/>
        <input type="hidden" name="action" value="checkout"/>
        <input type="hidden" name="redirect" value="<?= h($_SERVER['REQUEST_URI'] ?? '/') ?>"/>

        <div class="modal-body">
          <div class="formGrid">
            <div class="full">
              <label style="font-size:12px; color: rgba(255,255,255,0.65);">Full name</label>
              <input class="input" name="full_name" placeholder="e.g., Alex Student"/>
            </div>

            <div>
              <label style="font-size:12px; color: rgba(255,255,255,0.65);">Email</label>
              <input class="input" name="email" placeholder="e.g., alex@example.com"/>
            </div>

            <div>
              <label style="font-size:12px; color: rgba(255,255,255,0.65);">Discount code</label>
              <input class="input" name="discount_code" placeholder="DMU10 or FRESHERS5"/>
            </div>

            <div class="full">
              <label style="font-size:12px; color: rgba(255,255,255,0.65);">Address</label>
              <input class="input" name="address" placeholder="Building, street, city, postcode"/>
            </div>
          </div>

          <div class="totals">
            <div class="trow"><span>Subtotal</span><span class="big"><?= money((float)$subtotal) ?></span></div>
            <div class="trow"><span>Shipping (calculated after discount)</span><span class="big">Auto</span></div>
            <div style="padding-top:6px; color: rgba(255,255,255,0.55);">
              This will create a fake order ID and clear the cart.
            </div>
          </div>
        </div>

        <div class="modal-actions">
          <button class="btn" type="button" onclick="closeCheckout()">Cancel</button>
          <button class="btn primary" type="submit">Place order (mock)</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const overlay = document.getElementById('overlay');
    const drawer = document.getElementById('drawer');
    const checkoutWrap = document.getElementById('checkoutWrap');

    function openCart(){
      overlay.classList.add('open');
      drawer.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    function closeCart(){
      overlay.classList.remove('open');
      drawer.classList.remove('open');
      document.body.style.overflow = '';
    }

    function openCheckout(){
      closeCart();
      checkoutWrap.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    function closeCheckout(){
      checkoutWrap.classList.remove('open');
      document.body.style.overflow = '';
    }

    function closeToast(){
      const t = document.getElementById('toast');
      if (t) t.remove();
    }

    // ESC handling
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeCheckout();
        closeCart();
        closeToast();
      }
    });
  </script>
</body>
</html>
