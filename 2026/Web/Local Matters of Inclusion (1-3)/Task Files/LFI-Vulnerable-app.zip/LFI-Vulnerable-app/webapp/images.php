<?php
/**
 * WARNING: This code is DELIBERATELY VULNERABLE to Local File Inclusion (LFI).
 * Do not use this in a production environment.
 */

// The 'page' parameter is taken directly from the URL (e.g., images.php?page=contact.php)
$file = $_GET['img'];

//Put checks in to increase the difficulty
$file = str_replace('../','',$file);

if (!str_starts_with($file, "/var/www/html/")) {
    echo 'What are you playing at!';
    die();
}

if (isset($file)) {
    // The vulnerability: The script trusts user input and includes the file 
    // without checking if it's restricted to a specific directory.
    // We attempt to detect the mime type to serve it "correctly"
    $type = mime_content_type($file);
    header("Content-Type: $type");

    // The vulnerability: readfile() outputs the content of any path provided
    readfile($file);
}