import mongoose from "mongoose";
const ProductSchema = new mongoose.Schema({ title: String, description: String, price: Number, sku: { type: String, unique: true }, stock: Number, categoryId: { type: mongoose.Schema.Types.ObjectId, ref: "Category" }, isActive: { type: Boolean, default: true } }, { timestamps: true });
export const Product = mongoose.model("Product", ProductSchema);
