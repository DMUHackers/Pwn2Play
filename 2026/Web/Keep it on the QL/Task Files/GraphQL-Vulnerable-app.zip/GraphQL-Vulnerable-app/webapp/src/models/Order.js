
import mongoose from "mongoose";

const OrderItemSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    quantity: { type: Number, required: true, min: 1 }
  },
  { _id: false }
);

const OrderSchema = new mongoose.Schema(
  {
    cartId: { type: String, required: true, index: true },
    status: { type: String, enum: ["PLACED", "CANCELLED", "FULFILLED"], default: "PLACED" },
    items: { type: [OrderItemSchema], required: true },
    total: { type: Number, required: true, min: 0 }
  },
  { timestamps: true }
);

export const Order = mongoose.model("Order", OrderSchema);
