import mongoose from "mongoose";
const UserSchema = new mongoose.Schema({ email: { type: String, unique: true }, passwordHash: String, role: { type: String, default: "USER" } }, { timestamps: true });
export const User = mongoose.model("User", UserSchema);
