import jwt from "jsonwebtoken";
import { config } from "./config.js";

export function signToken(user) {
  return jwt.sign({ sub: user._id.toString(), role: user.role }, config.jwtSecret, { expiresIn: "7d" });
}

export function getUserFromAuthHeader(authHeader) {
  if (!authHeader) return null;
  const [scheme, token] = authHeader.split(" ");
  if (scheme !== "Bearer" || !token) return null;
  try { return jwt.verify(token, config.jwtSecret); } catch { return null; }
}

export function requireAuth(ctx) { if (!ctx.user) throw new Error("Not authenticated"); }
export function requireAdmin(ctx) { requireAuth(ctx); if (ctx.user.role !== "ADMIN") throw new Error("Admin only"); }
