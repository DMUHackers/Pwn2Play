import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import { ApolloServerPluginDrainHttpServer } from "@apollo/server/plugin/drainHttpServer";

import { connectDb } from "./db.js";
import { typeDefs } from "./schema.js";
import { resolvers } from "./resolvers/index.js";
import { getUserFromAuthHeader } from "./auth.js";
import { config } from "./config.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve React build from ../frontend/dist (built during Docker image build)
const frontendPath = path.join(__dirname, "../frontend/dist");

async function main() {
  await connectDb();

  const app = express();
  const httpServer = http.createServer(app);

  const server = new ApolloServer({
    typeDefs,
    resolvers,
    plugins: [ApolloServerPluginDrainHttpServer({ httpServer })]
  });

  await server.start();

  // Same-origin in the single-port setup; CORS is kept permissive for local tooling.
  app.use(cors());
  app.use(express.json());
  app.use(cookieParser());

  // Static frontend
  app.use(express.static(frontendPath));

  // GraphQL API
  app.use(
    "/graphql",
    expressMiddleware(server, {
      context: async ({ req, res }) => ({
        user: getUserFromAuthHeader(req.headers.authorization),
        req,
        res
      })
    })
  );

  // React Router fallback (must be after /graphql)
  app.get("*", (_req, res) => {
    res.sendFile(path.join(frontendPath, "index.html"));
  });

  await new Promise((resolve) => httpServer.listen({ port: config.port }, resolve));
  console.log(`App ready at http://localhost:${config.port} (GraphQL at /graphql)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
