
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";

import { User } from "../models/User.js";
import { Category } from "../models/Category.js";
import { Product } from "../models/Product.js";
import { Cart } from "../models/Cart.js";
import { Order } from "../models/Order.js";
import { signToken } from "../auth.js";

const CART_COOKIE = "cartId";

/**
 * Cookie-based cart sessions (no authentication).
 * - If cartId cookie exists: use it
 * - Else: mint a new cartId, set cookie, and create a cart document
 */
async function getOrCreateCart(ctx) {
  const req = ctx.req;
  const res = ctx.res;

  let cartId = req?.cookies?.[CART_COOKIE];

  if (!cartId) {
    cartId = randomUUID();
    // For local dev over http: secure=false. SameSite=Lax is fine for same-site navigation.
    res?.cookie?.(CART_COOKIE, cartId, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      path: "/"
    });
  }

  let cart = await Cart.findOne({ cartId });
  if (!cart) cart = await Cart.create({ cartId, items: [] });

  return cart;
}

export const resolvers = {
  Query: {
    _hiddenFlag: () => process.env.FLAG_VALUE || "P2P{CHANGE_ME}",
    // Optional auth endpoint support
    me: async (_, __, ctx) => (ctx.user ? User.findById(ctx.user.sub) : null),

    categories: async () => Category.find().sort({ name: 1 }).lean().exec(),
    products: async () => Product.find({ isActive: true }).sort({ createdAt: -1 }).lean().exec(),

    // Public, cookie-based session cart
    cart: async (_, __, ctx) => getOrCreateCart(ctx),

    // Public orders for the current cart session
    myOrders: async (_, __, ctx) => {
      const cart = await getOrCreateCart(ctx);
      return Order.find({ cartId: cart.cartId }).sort({ createdAt: -1 }).lean().exec();
    }
  },

  Mutation: {
    // Keep auth endpoints (optional)
    register: async (_, { email, password }) => {
      const existing = await User.findOne({ email: email.toLowerCase() });
      if (existing) throw new Error("Email already in use");
      if (password.length < 8) throw new Error("Password must be at least 8 characters");

      const passwordHash = await bcrypt.hash(password, 12);
      const user = await User.create({ email: email.toLowerCase(), passwordHash, role: "USER" });
      return { token: signToken(user), user };
    },

    login: async (_, { email, password }) => {
      const user = await User.findOne({ email: email.toLowerCase() });
      if (!user) throw new Error("Invalid credentials");
      const ok = await bcrypt.compare(password, user.passwordHash);
      if (!ok) throw new Error("Invalid credentials");
      return { token: signToken(user), user };
    },

    addToCart: async (_, { productId, quantity }, ctx) => {
      if (quantity < 1) throw new Error("Quantity must be >= 1");

      const product = await Product.findById(productId);
      if (!product || !product.isActive) throw new Error("Product not found");
      if (product.stock < quantity) throw new Error("Insufficient stock");

      const cart = await getOrCreateCart(ctx);
      const idx = cart.items.findIndex((i) => i.productId.toString() === productId);

      if (idx >= 0) cart.items[idx].quantity += quantity;
      else cart.items.push({ productId, quantity });

      await cart.save();
      return cart;
    },

    placeOrder: async (_, __, ctx) => {
      const cart = await getOrCreateCart(ctx);
      if (!cart.items.length) throw new Error("Cart is empty");

      const productIds = cart.items.map((i) => i.productId);
      const products = await Product.find({ _id: { $in: productIds }, isActive: true });
      const productMap = new Map(products.map((p) => [p._id.toString(), p]));

      let total = 0;
      const items = [];

      for (const item of cart.items) {
        const p = productMap.get(item.productId.toString());
        if (!p) throw new Error("One or more products are unavailable");
        if (p.stock < item.quantity) throw new Error(`Insufficient stock for SKU ${p.sku}`);

        total += p.price * item.quantity;
        items.push({ title: p.title, price: p.price, quantity: item.quantity });
      }

      // Decrement stock (MVP approach)
      for (const item of cart.items) {
        await Product.updateOne(
          { _id: item.productId, stock: { $gte: item.quantity } },
          { $inc: { stock: -item.quantity } }
        );
      }

      const order = await Order.create({
        cartId: cart.cartId,
        status: "PLACED",
        items,
        total
      });

      cart.items = [];
      await cart.save();

      return order;
    }
  },

  Product: {
    id: (p) => p._id.toString(),
    category: async (p) => Category.findById(p.categoryId).lean().exec()
  },
  Category: { id: (c) => c._id.toString() },
  Cart: { id: (c) => c._id.toString() },
  CartItem: { product: async (i) => Product.findById(i.productId).lean().exec() },
  User: { id: (u) => u._id.toString() },
  Order: { id: (o) => o._id.toString() }
};
