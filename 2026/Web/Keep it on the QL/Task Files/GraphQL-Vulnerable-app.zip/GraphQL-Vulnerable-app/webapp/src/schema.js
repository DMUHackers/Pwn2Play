export const typeDefs = `#graphql
  enum Role { USER ADMIN }
  enum OrderStatus { PLACED CANCELLED FULFILLED }
  type User { id: ID! email: String! role: Role! }
  type AuthPayload { token: String! user: User! }
  type Category { id: ID! name: String! slug: String! }
  type Product { id: ID! title: String! price: Float! sku: String! stock: Int! category: Category! }
  type CartItem { product: Product! quantity: Int! }
  type Cart { id: ID! items: [CartItem!]! }
  type OrderItem { title: String! price: Float! quantity: Int! }
  type Order { id: ID! status: OrderStatus! items: [OrderItem!]! total: Float! }

  type Query {
    _hiddenFlag: String
    me: User
    categories: [Category!]!
    products: [Product!]!
    cart: Cart!
    myOrders: [Order!]!
  }

  type Mutation {
    register(email: String!, password: String!): AuthPayload!
    login(email: String!, password: String!): AuthPayload!
    addToCart(productId: ID!, quantity: Int!): Cart!
    placeOrder: Order!
  }
`;
