
import bcrypt from "bcryptjs";
import { connectDb } from "./db.js";
import { config } from "./config.js";
import { User } from "./models/User.js";
import { Category } from "./models/Category.js";
import { Product } from "./models/Product.js";

function slugify(s) {
  return s.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
}

await connectDb();

// Optional admin (kept for future admin CRUD expansion)
const adminEmail = config.adminSeedEmail.toLowerCase();
let admin = await User.findOne({ email: adminEmail });
if (!admin) {
  admin = await User.create({
    email: adminEmail,
    passwordHash: await bcrypt.hash(config.adminSeedPassword, 12),
    role: "ADMIN"
  });
}

// Categories (with a security flavor)
const catNames = ["Ethical Snacks", "Pentest Pantry", "Crypto Corner"];
const categories = [];
for (const name of catNames) {
  const slug = slugify(name);
  const c = await Category.findOneAndUpdate(
    { slug },
    { name, slug },
    { upsert: true, new: true }
  );
  categories.push(c);
}
const [ethical, pentest, crypto] = categories;

// Ethical hacking pun products (harmless, educational flavor)
const products = [
  {
    title: "Phish & Chips",
    description: "A crunchy reminder: verify your source before you bite.",
    price: 4.99,
    sku: "SEC-PHISH-001",
    stock: 120,
    categoryId: ethical._id,
    isActive: true
  },
  {
    title: "Zero-Day Doughnuts",
    description: "So fresh they ship before the patch notes.",
    price: 6.25,
    sku: "SEC-ZERODAY-001",
    stock: 90,
    categoryId: ethical._id,
    isActive: true
  },
  {
    title: "Brute-Force Breadsticks",
    description: "Try every dip until you find the right one.",
    price: 3.75,
    sku: "SEC-BRUTE-001",
    stock: 150,
    categoryId: pentest._id,
    isActive: true
  },
  {
    title: "SQLi Salsa (Injection-Resistant Recipe)",
    description: "Prepared statements, not spicy statements.",
    price: 5.50,
    sku: "SEC-SQLI-001",
    stock: 80,
    categoryId: pentest._id,
    isActive: true
  },
  {
    title: "XSSpress Espresso Beans",
    description: "Escape properly or it gets bitter.",
    price: 9.95,
    sku: "SEC-XSS-001",
    stock: 60,
    categoryId: pentest._id,
    isActive: true
  },
  {
    title: "Cookie Monster Session Jar",
    description: "HttpOnly, because monsters should not read your cookies.",
    price: 12.49,
    sku: "SEC-COOKIE-001",
    stock: 45,
    categoryId: ethical._id,
    isActive: true
  },
  {
    title: "Hash Browns (Salted)",
    description: "Seasoned with salt, pepper, and a responsible KDF.",
    price: 4.25,
    sku: "SEC-HASH-001",
    stock: 110,
    categoryId: crypto._id,
    isActive: true
  },
  {
    title: "Nonce Sense Nibbles",
    description: "One-time treats for one-time use.",
    price: 3.10,
    sku: "SEC-NONCE-001",
    stock: 140,
    categoryId: crypto._id,
    isActive: true
  },
  {
    title: "Man-in-the-Middle Mint Tea",
    description: "End-to-end steeping recommended.",
    price: 7.40,
    sku: "SEC-MITM-001",
    stock: 70,
    categoryId: ethical._id,
    isActive: true
  },
  {
    title: "Firewall Fruit Roll-Ups",
    description: "Keeps the bad packets out; keeps the good vibes in.",
    price: 2.95,
    sku: "SEC-FW-001",
    stock: 200,
    categoryId: ethical._id,
    isActive: true
  },
  {
    title: "Patch Tuesday Taco Kit",
    description: "Deploy hotfixes. Eat hot sauces.",
    price: 8.99,
    sku: "SEC-PATCH-001",
    stock: 65,
    categoryId: pentest._id,
    isActive: true
  },
  {
    title: "Least-Privilege Peanut Mix",
    description: "Only the nuts you need—nothing more.",
    price: 4.60,
    sku: "SEC-LP-001",
    stock: 95,
    categoryId: ethical._id,
    isActive: true
  }
];

for (const p of products) {
  await Product.findOneAndUpdate({ sku: p.sku }, p, { upsert: true, new: true });
}

console.log("Seed complete (ethical hacking pun products loaded)");
process.exit(0);
