import dotenv from "dotenv";
dotenv.config();

export const config = {
  port: Number(process.env.PORT || 4000),
  mongoUri: process.env.MONGO_URI || "mongodb://localhost:27017/shop",
  jwtSecret: process.env.JWT_SECRET || "dev-secret",
  adminSeedEmail: process.env.ADMIN_SEED_EMAIL || "admin@example.com",
  adminSeedPassword: process.env.ADMIN_SEED_PASSWORD || "Admin123!"
};
