import mongoose from "mongoose";
const CategorySchema = new mongoose.Schema({ name: String, slug: { type: String, unique: true } }, { timestamps: true });
export const Category = mongoose.model("Category", CategorySchema);
