import { gql } from "@apollo/client";

export const ME = gql`
  query Me {
    me { id email role }
  }
`;

export const PRODUCTS = gql`
  query Products {
    products { id title price sku stock category { id name slug } }
  }
`;

export const CART = gql`
  query Cart {
    cart { id items { quantity product { id title price sku stock } } }
  }
`;

export const MY_ORDERS = gql`
  query MyOrders {
    myOrders { id status total items { title price quantity } }
  }
`;

export const REGISTER = gql`
  mutation Register($email: String!, $password: String!) {
    register(email: $email, password: $password) {
      token
      user { id email role }
    }
  }
`;

export const LOGIN = gql`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      token
      user { id email role }
    }
  }
`;

export const ADD_TO_CART = gql`
  mutation AddToCart($productId: ID!, $quantity: Int!) {
    addToCart(productId: $productId, quantity: $quantity) {
      id
      items { quantity product { id title price sku stock } }
    }
  }
`;

export const PLACE_ORDER = gql`
  mutation PlaceOrder {
    placeOrder { id status total items { title price quantity } }
  }
`;
