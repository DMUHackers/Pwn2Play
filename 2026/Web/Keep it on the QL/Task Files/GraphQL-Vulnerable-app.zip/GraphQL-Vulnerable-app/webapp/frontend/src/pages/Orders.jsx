import React from "react";
import { useQuery } from "@apollo/client";
import { MY_ORDERS } from "../graphql.js";

export default function Orders() {
  const { data, loading, error, refetch } = useQuery(MY_ORDERS, { fetchPolicy: "network-only" });

  if (loading) return <div>Loading…</div>;
  if (error) return <div className="error">{error.message}</div>;

  const orders = data?.myOrders || [];

  return (
    <div>
      <div className="row">
        <div className="h2 glitch" data-text="ORDERS">ORDERS</div>
        <button onClick={() => refetch()}>Refresh</button>
      </div>
      <div className="hr"></div>

      {orders.length === 0 ? (
        <div className="card">No orders yet.</div>
      ) : (
        <div className="grid">
          {orders.map((o) => (
            <div key={o.id} className="card">
              <div className="row">
                <div>
                  <div style={{ fontWeight: 800 }}>Order {o.id}</div>
                  <div className="muted">Status: {o.status}</div>
                </div>
                <div style={{ fontWeight: 900 }}>£{o.total.toFixed(2)}</div>
              </div>

              <div className="grid" style={{ marginTop: 10 }}>
                {o.items.map((it, idx) => (
                  <div key={idx} className="row">
                    <div className="muted">{it.title}</div>
                    <div className="muted">
                      {it.quantity} × £{it.price.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
