import React, { useState } from "react";
import { useMutation } from "@apollo/client";
import { LOGIN, REGISTER } from "../graphql.js";
import { useNavigate } from "react-router-dom";

export default function Auth() {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const [login, loginState] = useMutation(LOGIN);
  const [register, registerState] = useMutation(REGISTER);

  const loading = loginState.loading || registerState.loading;
  const error = loginState.error || registerState.error;

  const submit = async (e) => {
    e.preventDefault();
    const fn = mode === "login" ? login : register;
    const res = await fn({ variables: { email, password } });
    const token = res?.data?.login?.token || res?.data?.register?.token;
    if (token) {
      localStorage.setItem("token", token);
      navigate("/");
    }
  };

  return (
    <div>
      <div className="h2 glitch" data-text="ACCESS">ACCESS</div><div className="hr"></div>
      <div className="row">
        <button disabled={mode === "login"} onClick={() => setMode("login")}>Login</button>
        <button disabled={mode === "register"} onClick={() => setMode("register")}>Register</button>
      </div>

      <form onSubmit={submit} className="grid" style={{ maxWidth: 420 }}>
        <label>
          Email
          <input value={email} onChange={(e) => setEmail(e.target.value)}  />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}  />
        </label>
        <button disabled={loading} type="submit">{loading ? "Working..." : "Submit"}</button>
        {error ? <div style={{ color: "crimson" }}>{error.message}</div> : null}
      </form>
      
    </div>
  );
}
