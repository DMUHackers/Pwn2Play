import React from "react";
import { useQuery, useMutation } from "@apollo/client";
import { CART, PLACE_ORDER } from "../graphql.js";

export default function Cart() {
  const { data, loading, error, refetch } = useQuery(CART, { fetchPolicy: "network-only" });
  const [placeOrder, placeState] = useMutation(PLACE_ORDER);

  const place = async () => {
    try {
      const res = await placeOrder();
      alert(`Order placed: ${res.data.placeOrder.id}`);
      await refetch();
    } catch (e) {
      alert(e.message);
    }
  };

  if (loading) return <div>Loading…</div>;
  if (error) return <div className="error">{error.message}</div>;

  const items = data?.cart?.items || [];
  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  return (
    <div>
      <div className="row">
        <div className="h2 glitch" data-text="CART">CART</div>
        <button onClick={() => refetch()}>Refresh</button>
      </div>
      <div className="hr"></div>

      {items.length === 0 ? (
        <div className="card">Your cart is empty.</div>
      ) : (
        <div className="grid">
          {items.map((i) => (
            <div key={i.product.id} className="card">
              <div className="row">
                <div>
                  <div style={{ fontWeight: 700 }}>{i.product.title}</div>
                  <div className="muted">SKU {i.product.sku}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="muted">Qty: {i.quantity}</div>
                  <div style={{ fontWeight: 800 }}>£{(i.product.price * i.quantity).toFixed(2)}</div>
                </div>
              </div>
            </div>
          ))}

          <div className="row">
            <div style={{ fontWeight: 900 }}>Total: £{total.toFixed(2)}</div>
            <button disabled={placeState.loading} onClick={place}>
              {placeState.loading ? "Placing…" : "Place order"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
