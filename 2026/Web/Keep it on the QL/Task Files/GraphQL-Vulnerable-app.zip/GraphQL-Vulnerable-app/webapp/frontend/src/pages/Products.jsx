import React, { useState } from "react";
import { useQuery, useMutation } from "@apollo/client";
import { PRODUCTS, ADD_TO_CART } from "../graphql.js";

export default function Products() {
  const { data, loading, error, refetch } = useQuery(PRODUCTS);
  const [addToCart, addState] = useMutation(ADD_TO_CART);
  const [qty, setQty] = useState(1);

  const add = async (productId) => {
    try {
      await addToCart({ variables: { productId, quantity: Number(qty) } });
      alert("Added to cart");
    } catch (e) {
      alert(e.message);
    }
  };

  if (loading) return <div>Loading…</div>;
  if (error) return <div style={{ color: "crimson" }}>{error.message}</div>;

  return (
    <div>
      <div className="row">
        <div className="h2 glitch" data-text="PRODUCTS">PRODUCTS</div>
        <button onClick={() => refetch()}>Refresh</button>
      </div>
      <div className="hr"></div>

      <div className="card">
        <label>
          Quantity to add:
          <input
            type="number"
            min="1"
            value={qty}
            onChange={(e) => setQty(e.target.value)}
            style={{ width: 90, marginLeft: 10 }}
          />
        </label>
      </div>

      <div className="grid">
        {data.products.map((p) => (
          <div key={p.id} className="card">
            <div className="row">
              <div>
                <div style={{ fontWeight: 600 }}>{p.title}</div>
                <div className="muted">{p.category?.name} • SKU {p.sku}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div>£{p.price.toFixed(2)}</div>
                <div className={p.stock > 0 ? "muted" : "error"}>Stock: {p.stock}</div>
              </div>
            </div>
            <div style={{ marginTop: 10 }}>
              <button disabled={addState.loading || p.stock <= 0} onClick={() => add(p.id)}>
                Add to cart
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
