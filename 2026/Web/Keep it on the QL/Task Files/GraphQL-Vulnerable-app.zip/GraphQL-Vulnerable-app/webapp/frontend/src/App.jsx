import React from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import Products from "./pages/Products.jsx";
import Cart from "./pages/Cart.jsx";
import Orders from "./pages/Orders.jsx";
import Auth from "./pages/Auth.jsx";


function Nav() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div className="topbar">
      <div className="nav">
        <div className="brand">
          <div className="brandMark" />
          <div className="brandTitle glitch" data-text="KEEP IT ON THE QL">KEEP IT ON THE QL</div>
        </div>
        <Link to="/">Products</Link>
        <Link to="/cart">Cart</Link>
        <Link to="/orders">Orders</Link>
        <div className="spacer" />
        {!token ? (
          <Link to="/auth" className="btn" style={{ padding: "8px 10px" }}>
            Login / Register
          </Link>
        ) : (
          <button onClick={logout}>Logout</button>
        )}
      </div>
    </div>
  );
}


export default function App() {
  return (
    <div className="scanlines">
      <Nav />
      <div className="container">
        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/orders" element={<Orders />} />
        </Routes>
      </div>
    </div>
  );
}
