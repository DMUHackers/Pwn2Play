# Keep It On The QL

A **Node.js + GraphQL + MongoDB** shopping application, with a key GraphQL vulnerability.

## CTF Description

Welcome to Keep It On The QL, a cyber-punk storefront glowing with neon lights and questionable engineering decisions. 

Your objective is straightforward: retrieve the flag. How you approach the challenge is up to you, but remember every system tells a story, and sometimes the loudest secrets are hidden in plain sight. Stay sharp, stay curious, and whatever you do... keep it on the QL.

## Setup and Operation

**Swapping Out Flag(s)**

Edit the `./webapp/.env` file accordingly.

**Run the Images**

The below will start webservers on localhost:4000, i.e [http://localhost:4000](http://localhost:4000).

```
cd webapp
docker compose up -d
docker compose exec api npm run seed
```

**Stop the Image**

The below can be used to stop/reset the image.

```
cd webapp
docker compose down -v
```