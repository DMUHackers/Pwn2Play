<?php
declare(strict_types=1);

require __DIR__ . '/../app/Blog.php';
require __DIR__ . '/../app/render.php';

use App\Blog;

$blog = new Blog(require __DIR__ . '/../data/posts.php');

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rtrim($path, '/') ?: '/';

if ($path === '/') {
    $q = trim((string)($_GET['q'] ?? ''));
    $posts = $q === '' ? $blog->all() : $blog->search($q);

    echo render('layout', [
        'title' => 'Leicestershire & DMU Pun-derground Blog',
        'content' => render('home', [
            'posts' => $posts,
            'q' => $q
        ])
    ]);
    exit;
}

if ($path === '/post') {
    $slug = (string)($_GET['slug'] ?? '');
    $post = $blog->findBySlug($slug);

    if (!$post) {
        http_response_code(404);
        echo render('layout', [
            'title' => '404 — Lost in the Leics lanes',
            'content' => render('notfound', ['slug' => $slug])
        ]);
        exit;
    }

    echo render('layout', [
        'title' => $post['title'] . ' — Leics & DMU',
        'content' => render('post', ['post' => $post])
    ]);
    exit;
}

if ($path === '/about') {
    echo render('layout', [
        'title' => 'About — De Montfort-able reading',
        'content' => render('about', [])
    ]);
    exit;
}

http_response_code(404);
echo render('layout', [
    'title' => '404 — This page is Leicester… sorry, lesser',
    'content' => render('notfound', ['slug' => $path])
]);
