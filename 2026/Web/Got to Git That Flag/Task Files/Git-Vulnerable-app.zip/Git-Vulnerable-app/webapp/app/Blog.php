<?php
declare(strict_types=1);

namespace App;

final class Blog
{
    /** @var array<int, array<string, mixed>> */
    private array $posts;

    /**
     * @param array<int, array<string, mixed>> $posts
     */
    public function __construct(array $posts)
    {
        usort($posts, function ($a, $b) {
            return strcmp((string)$b['date'], (string)$a['date']);
        });

        $this->posts = $posts;
    }

    /** @return array<int, array<string, mixed>> */
    public function all(): array
    {
        return $this->posts;
    }

    /** @return array<string, mixed>|null */
    public function findBySlug(string $slug): ?array
    {
        foreach ($this->posts as $post) {
            if (($post['slug'] ?? '') === $slug) {
                return $post;
            }
        }
        return null;
    }

    /** @return array<int, array<string, mixed>> */
    public function search(string $q): array
    {
        $q = mb_strtolower(trim($q));
        if ($q === '') {
            return $this->all();
        }

        $out = [];
        foreach ($this->posts as $post) {
            $hay = implode("\n", [
                (string)($post['title'] ?? ''),
                (string)($post['excerpt'] ?? ''),
                (string)($post['body'] ?? ''),
                implode(' ', (array)($post['tags'] ?? [])),
            ]);

            if (mb_strpos(mb_strtolower($hay), $q) !== false) {
                $out[] = $post;
            }
        }
        return $out;
    }
}
