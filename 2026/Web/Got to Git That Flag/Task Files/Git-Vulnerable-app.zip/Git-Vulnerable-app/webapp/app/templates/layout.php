<?php declare(strict_types=1); ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($title ?? 'Leics & DMU Blog') ?></title>
  <link rel="stylesheet" href="/assets/style.css" />
</head>
<body>
  <header class="site-header">
    <div class="wrap">
      <a class="brand" href="/">Leics × DMU</a>
      <nav class="nav">
        <a href="/">Home</a>
        <a href="/about">About</a>
      </nav>
    </div>
  </header>

  <main class="wrap">
    <?= $content ?? '' ?>
  </main>

  <footer class="site-footer">
    <div class="wrap">
      <small>
        Built with PHP and an unhealthy love of puns. Leicester is never the lesser.
      </small>
    </div>
  </footer>
</body>
</html>
