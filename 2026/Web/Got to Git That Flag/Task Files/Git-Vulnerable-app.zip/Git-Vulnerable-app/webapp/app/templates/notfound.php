<?php declare(strict_types=1); ?>
<section class="card">
  <h1>404</h1>
  <p>
    We couldn’t find <code><?= htmlspecialchars((string)($slug ?? 'that')) ?></code>.
    It’s gone walkabout—like a student looking for the “quiet floor” after a deadline.
  </p>
  <p><a href="/">Go home</a></p>
</section>
