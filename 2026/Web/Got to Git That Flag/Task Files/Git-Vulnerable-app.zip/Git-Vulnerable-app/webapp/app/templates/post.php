<?php declare(strict_types=1); ?>
<article class="post">
  <div class="meta">
    <span><?= htmlspecialchars((string)$post['date']) ?></span>
    <span class="dot">•</span>
    <span><?= htmlspecialchars(implode(', ', (array)($post['tags'] ?? []))) ?></span>
  </div>

  <h1><?= htmlspecialchars((string)$post['title']) ?></h1>

  <div class="post-body">
    <?php
      $body = (string)($post['body'] ?? '');
      $paras = preg_split("/\R\R+/", trim($body)) ?: [];
      foreach ($paras as $para) {
          echo '<p>' . nl2br(htmlspecialchars(trim($para))) . "</p>\n";
      }
    ?>
  </div>

  <p class="back"><a href="/">← Back to home</a></p>
</article>
