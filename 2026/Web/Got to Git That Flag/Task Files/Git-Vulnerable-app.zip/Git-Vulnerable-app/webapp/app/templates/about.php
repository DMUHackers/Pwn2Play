<?php declare(strict_types=1); ?>
<section class="card">
  <h1>About</h1>
  <p>
    This is a demo PHP blog with sample content about Leicestershire and De Montfort University (DMU).
    It is intentionally light-weight: no database, no frameworks, just files and vibes.
  </p>
  <p>
    The tone is proudly pun-first. If you came for serious analysis, we regret to inform you:
    you have entered the pun-derground.
  </p>
</section>
