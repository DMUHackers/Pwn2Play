<?php declare(strict_types=1); ?>
<section class="hero">
  <h1>Leicestershire & DMU: pun-licensed commentary</h1>
  <p>
    A small blog where Leicester is never the lesser, and De Montfort is always de-more-fun.
  </p>

  <form class="search" method="get" action="/">
    <input type="text" name="q" placeholder="Search posts (e.g., 'campus', 'fox', 'crisps')"
           value="<?= htmlspecialchars($q ?? '') ?>" />
    <button type="submit">Search</button>
  </form>
</section>

<section class="grid">
  <?php if (empty($posts)): ?>
    <div class="card">
      <h2>No results</h2>
      <p>We looked far and wide—like a student hunting a free socket in the library.</p>
    </div>
  <?php endif; ?>

  <?php foreach ($posts as $p): ?>
    <article class="card">
      <div class="meta">
        <span><?= htmlspecialchars((string)$p['date']) ?></span>
        <span class="dot">•</span>
        <span><?= htmlspecialchars(implode(', ', (array)($p['tags'] ?? []))) ?></span>
      </div>
      <h2>
        <a href="/post?slug=<?= urlencode((string)$p['slug']) ?>">
          <?= htmlspecialchars((string)$p['title']) ?>
        </a>
      </h2>
      <p><?= htmlspecialchars((string)$p['excerpt']) ?></p>
      <a class="more" href="/post?slug=<?= urlencode((string)$p['slug']) ?>">Read more →</a>
    </article>
  <?php endforeach; ?>
</section>
