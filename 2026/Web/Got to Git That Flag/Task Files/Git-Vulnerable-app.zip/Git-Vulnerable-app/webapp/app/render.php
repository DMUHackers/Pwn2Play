<?php
declare(strict_types=1);

function render(string $name, array $vars): string
{
    $tpl = __DIR__ . "/templates/{$name}.php";
    if (!is_file($tpl)) {
        throw new RuntimeException("Template not found: {$name}");
    }

    extract($vars, EXTR_SKIP);
    ob_start();
    require $tpl;
    return (string)ob_get_clean();
}
