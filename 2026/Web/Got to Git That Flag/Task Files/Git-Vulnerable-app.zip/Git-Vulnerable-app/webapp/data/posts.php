<?php
declare(strict_types=1);

return [
  [
    'slug' => 'leicester-the-lesser-never',
    'date' => '2025-10-14',
    'title' => 'Leicester? I hardly know ’er. (Also: it’s never the lesser.)',
    'tags' => ['Leicester', 'puns', 'local'],
    'excerpt' => 'A spirited defence of the city: if you call it “lesser”, you’ll be firmly corrected—with a smile.',
    'body' => 'Some people say “Leicester is the lesser.” That’s a mis-steak. And yes, I will die on this hill—possibly with a Melton Mowbray pork pie in hand.

The city’s charm is that it doesn’t try too hard; it just Leicester-ns calmly and gets on with it. You want history? We’ve got it. You want food? We’ll feed you until you’re officially a citizen of Snackingham.

And if you’re visiting DMU, remember: De Montfort isn’t just a name—it’s a promise. You can always expect de-more-fun than you planned.',
  ],
  [
    'slug' => 'dmu-de-more-fun',
    'date' => '2025-06-02',
    'title' => 'DMU: De-Montfort-able levels of productivity (allegedly)',
    'tags' => ['DMU', 'campus', 'student life'],
    'excerpt' => 'A lovingly unrealistic guide to being organised on campus, featuring coffee and denial.',
    'body' => 'Welcome to DMU, where deadlines are real, sleep is optional, and “I’ll start tomorrow” is a cherished local dialect.

Step one: acquire coffee. Step two: acquire another coffee to cope with step one. Step three: open your laptop and stare into the academic abyss until the abyss offers you a group project.

Still, DMU has a way of turning chaos into competence. Not always immediately. Sometimes it’s more of a “deferred montfortification.”',
  ],
  [
    'slug' => 'curveball-at-the-curve',
    'date' => '2025-02-12',
    'title' => 'Curve Theatre: getting curve-balled by culture',
    'tags' => ['Leicester', 'arts', 'nights out'],
    'excerpt' => 'An evening at The Curve that left me cultured, hydrated, and only mildly confused by modern choreography.',
    'body' => 'The Curve is where you go to be impressed and to learn that your “casual outfit” is someone else’s formalwear.

I went for the show; I stayed for the interval snacks. In Leicester, even culture comes with crisps.

If art bends your brain, don’t panic. It’s just a curveball. (That was the last one. It wasn’t.)',
  ],
  [
    'slug' => 'leicestershire-walks-and-pun-trails',
    'date' => '2024-09-08',
    'title' => 'Leicestershire walks: taking the scenic route (a.k.a. the pun-trail)',
    'tags' => ['Leicestershire', 'outdoors', 'weekends'],
    'excerpt' => 'Fresh air, decent views, and at least one joke per mile. Doctor’s orders (not a real doctor).',
    'body' => 'If you’re in Leicestershire and you’re feeling stressed, I prescribe a walk. Side effects may include: improved mood, sudden interest in “nice trees,” and an inability to stop saying “leaf me alone.”

Bring a friend, or go solo and pretend you’re in a moody indie film. Either way, remember: the goal is to return home feeling recharged, not to set a personal record for “most dramatic hill sigh.”

If you pass someone and they nod politely, that’s not awkwardness. That’s just local small-talk: scenic and concise.',
  ],
  [
    'slug' => 'market-harbours-pasties',
    'date' => '2024-03-11',
    'title' => 'Market Harborough: where the pasties are past-yes',
    'tags' => ['Leicestershire', 'food', 'trips'],
    'excerpt' => 'A field report on carbs, charm, and the fine art of pretending you only came for one snack.',
    'body' => 'Market Harborough is proof that you can be both quaint and dangerously well-fed.

I arrived with a plan: stroll, browse, behave. I left with a bag that said “artisan” and a regret that said “portion size.”

If you see a bakery queue, join it. In Harborough, that line is basically a cultural heritage site.',
  ],
  [
    'slug' => 'dmu-library-socket-safari',
    'date' => '2023-11-20',
    'title' => 'DMU Library: the great socket safari',
    'tags' => ['DMU', 'study', 'survival'],
    'excerpt' => 'A noble quest for power, Wi-Fi, and inner peace (spoiler: inner peace is out of stock).',
    'body' => 'Every DMU student learns the ancient ritual: enter the library, scan for sockets, whisper “please” to the gods of extension leads.

When you find one, do not celebrate. Sit down calmly. Make eye contact with nobody. The socket can sense fear, and it will betray you.

Remember: charging your laptop is important, but charging your spirit is importanter. (That is a word now.)',
  ],
  [
    'slug' => 'foxes-and-footnotes',
    'date' => '2022-10-01',
    'title' => 'Foxes and footnotes: Leicester nights, DMU deadlines',
    'tags' => ['Leicester', 'DMU', 'culture'],
    'excerpt' => 'The duality of the city: lively evenings and academically ominous mornings.',
    'body' => 'Leicester nights can be lively; DMU mornings can be… educational.

One moment you’re enjoying the city, the next you’re writing footnotes like your life depends on it. Maybe it does. Maybe it’s just your grade.

Either way, hydrate, cite your sources, and remember: the fox is clever, but the bibliography is cleverer.',
  ],
  [
    'slug' => 'leics-crisps-research',
    'date' => '2021-04-17',
    'title' => 'Important research: Leicestershire crisps per capita',
    'tags' => ['Leicestershire', 'snacks', 'totally-science'],
    'excerpt' => 'A rigorous study (peer reviewed by nobody) on snack density.',
    'body' => 'This is not official data. It is snack-based scholarship (with extremely crunchy peer review).

Conclusion: Leicestershire contains a statistically significant number of snack opportunities.

Recommendation: if you are walking anywhere, bring crisps. This is both practical and morally correct.',
  ],
  [
    'slug' => 'dmu-groupwork-merges',
    'date' => '2020-02-22',
    'title' => 'DMU group work: like git merges, but with more feelings',
    'tags' => ['DMU', 'group work', 'pain'],
    'excerpt' => 'Conflicts will happen. Resolve them politely. Preferably before submission time.',
    'body' => 'Group work is a lot like a merge conflict: everyone is sure they’re right, and one person disappears until the final hour.

Tips: communicate early, document decisions, and when in doubt, choose the simplest solution. Also, name your group chat something unhinged. It builds morale.

If you make it through, you deserve a medal. Or at least a biscuit.',
  ],
  [
    'slug' => 'hello-leics',
    'date' => '2019-03-01',
    'title' => 'Hello Leicestershire: pun license granted',
    'tags' => ['Leicestershire', 'puns'],
    'excerpt' => 'A first post with entirely too much confidence.',
    'body' => 'Welcome. This blog is small, but its puns are aspirational.

Leicester? Hardly know ’er.

DMU? De-more-fun is the goal. De-more-sleep is the dream.',
  ],
];
