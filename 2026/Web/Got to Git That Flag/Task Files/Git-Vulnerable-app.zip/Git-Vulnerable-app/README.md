## Build the Image

```
docker build -t dmu-php-app-git .
```

## Run the Image

```
docker run --rm -p 8002:80 dmu-php-app-git
```

Exposes the webserver on http://localhost:8002

