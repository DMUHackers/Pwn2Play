# One Ring Nonce Collapse

## Inspiration
This challenge is inspired by **The Lord of the Rings**: one artifact governing many realms. Here, a single ECC private key governs a signing service, and a subtle nonce leak turns that power into a recoverable secret.

## Deployment
- **Challenge type:** Service-based (remote signing oracle)
- **Runtime:** Docker container running a Flask API
- **Flag handling:** The flag is stored server-side via `FLAG` environment variable (or `/flag.txt` fallback) and only returned after a valid signature over the protected phrase is submitted.

Build and run:

```bash
docker build -t one-ring-nonce-collapse .
docker run --rm -p 5000:5000 -e FLAG='P2P{0n3_r1ng_n0nc3_70_ru13_7h3_curv3}' one-ring-nonce-collapse
```

## Setup
Local setup for testing:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 server.py
```

Solve script usage:

```bash
python3 exploit.py -u http://127.0.0.1:5000
```

## Vulnerability
### Type
Biased ECDSA nonce generation with known most-significant bits, solved via a Hidden Number Problem lattice attack.

### Initial state
Players receive a remote service with:
- Public key endpoint
- Signature oracle endpoint (for arbitrary messages except one protected phrase)
- Verification endpoint that reveals the flag only for a valid protected-phrase signature

### Discovery
Each oracle signature includes a large nonce prefix hint (`nonce_msb`) and uses `k = (nonce_msb << UNKNOWN_BITS) + random_low_bits`. This means the lower `UNKNOWN_BITS` are the only entropy in each nonce.

### Technical details
For each signature `(r_i, s_i)` over hash `h_i` and modulus `n`:

` s_i = k_i^{-1}(h_i + d*r_i) mod n `

If `k_i = 2^u * msb_i + x_i` with small unknown `x_i < 2^u`, then:

` a_i*d + b_i = x_i mod n `

where:
- `a_i = r_i * s_i^{-1} mod n`
- `b_i = h_i * s_i^{-1} - 2^u*msb_i mod n`

This is a Hidden Number Problem instance with bounded errors `x_i`. With enough signatures, an LLL-reduced lattice reveals the private key `d`.

### Exploit
1. Query many signatures with known messages.
2. Collect `(h_i, r_i, s_i, nonce_msb_i)` tuples.
3. Build the HNP lattice basis and run LLL.
4. Extract private key candidate from reduced basis vectors.
5. Forge a signature for the protected message.
6. Submit forged signature to retrieve the flag.

### Root cause
Nonces are not uniformly random. Most bits are effectively known, leaving only a small unknown tail. ECDSA security critically depends on full-entropy, secret nonces.

### Educational value
- Demonstrates why **nonce leakage** in ECDSA is catastrophic
- Connects signature misuse to the **Hidden Number Problem**
- Shows practical usage of **LLL lattice reduction** in cryptanalysis
- Reinforces secure nonce generation requirements for real systems
