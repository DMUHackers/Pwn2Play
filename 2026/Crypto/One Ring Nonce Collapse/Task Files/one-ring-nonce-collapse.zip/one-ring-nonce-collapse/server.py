#!/usr/bin/env python3
"""Vulnerable ECDSA signing service with biased nonces."""

from __future__ import annotations

import hashlib
import os
import secrets
from pathlib import Path

from ecdsa import curves
from flask import Flask, jsonify, request

app = Flask(__name__)

CURVE = curves.SECP256k1
G = CURVE.generator
N = CURVE.order
UNKNOWN_BITS = 20
MAX_SIGNATURES = 56
PROTECTED_MESSAGE = "one ring to rule them all"


def _load_flag() -> str:
    env_flag = os.getenv("FLAG")
    if env_flag:
        return env_flag
    flag_path = Path("/flag.txt")
    if flag_path.exists():
        return flag_path.read_text(encoding="utf-8").strip()
    return "P2P{0n3_r1ng_n0nc3_70_ru13_7h3_curv3}"


FLAG = _load_flag()
seed_material = os.getenv("PRIVATE_SEED", secrets.token_hex(24)).encode()
PRIVATE_KEY = int.from_bytes(hashlib.sha256(seed_material).digest(), "big") % N
if PRIVATE_KEY == 0:
    PRIVATE_KEY = 1
PUBLIC_KEY = PRIVATE_KEY * G
issued_signatures = 0


def hash_message(message: str) -> int:
    return int.from_bytes(hashlib.sha256(message.encode()).digest(), "big") % N


def biased_nonce(message: str) -> tuple[int, int]:
    # The server leaks almost all nonce bits via nonce_msb.
    digest = int.from_bytes(hashlib.sha256(f"gondor::{message}".encode()).digest(), "big") % N
    nonce_msb = digest >> UNKNOWN_BITS
    nonce_low = secrets.randbits(UNKNOWN_BITS)
    k = (nonce_msb << UNKNOWN_BITS) | nonce_low
    if k <= 0 or k >= N:
        k = (k % (N - 1)) + 1
        nonce_msb = k >> UNKNOWN_BITS
    return k, nonce_msb


def sign_message(message: str) -> tuple[int, int, int, int]:
    h = hash_message(message)
    while True:
        k, nonce_msb = biased_nonce(message)
        r = int((k * G).x()) % N
        if r == 0:
            continue
        s = (pow(k, -1, N) * (h + PRIVATE_KEY * r)) % N
        if s == 0:
            continue
        return h, r, s, nonce_msb


def verify_signature(message: str, r: int, s: int) -> bool:
    if not (1 <= r < N and 1 <= s < N):
        return False
    h = hash_message(message)
    w = pow(s, -1, N)
    u1 = (h * w) % N
    u2 = (r * w) % N
    point = u1 * G + u2 * PUBLIC_KEY
    if point == curves.ellipticcurve.INFINITY:
        return False
    return (int(point.x()) % N) == r


@app.get("/")
def index() -> tuple[str, int]:
    return (
        "One Ring Nonce Collapse oracle online. Use /pubkey, /sign, and /verify.",
        200,
    )


@app.get("/pubkey")
def pubkey() -> tuple[dict, int]:
    return (
        {
            "curve": "secp256k1",
            "n": str(N),
            "gx": str(int(G.x())),
            "gy": str(int(G.y())),
            "pub_x": str(int(PUBLIC_KEY.x())),
            "pub_y": str(int(PUBLIC_KEY.y())),
            "unknown_bits": UNKNOWN_BITS,
            "protected_message": PROTECTED_MESSAGE,
            "max_signatures": MAX_SIGNATURES,
        },
        200,
    )


@app.post("/sign")
def sign() -> tuple[dict, int]:
    global issued_signatures
    body = request.get_json(silent=True) or {}
    message = str(body.get("message", ""))

    if not message:
        return {"error": "message is required"}, 400
    if message == PROTECTED_MESSAGE:
        return {"error": "that decree is sealed"}, 403
    if issued_signatures >= MAX_SIGNATURES:
        return {"error": "oracle exhausted"}, 429

    h, r, s, nonce_msb = sign_message(message)
    issued_signatures += 1
    return (
        {
            "message": message,
            "h": str(h),
            "r": str(r),
            "s": str(s),
            "nonce_msb": str(nonce_msb),
            "remaining": MAX_SIGNATURES - issued_signatures,
        },
        200,
    )


@app.post("/verify")
def verify() -> tuple[dict, int]:
    body = request.get_json(silent=True) or {}
    try:
        r = int(str(body.get("r", "")), 0)
        s = int(str(body.get("s", "")), 0)
    except ValueError:
        return {"error": "r and s must be integers"}, 400

    if verify_signature(PROTECTED_MESSAGE, r, s):
        return {"status": "accepted", "flag": FLAG}, 200
    return {"status": "rejected"}, 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
