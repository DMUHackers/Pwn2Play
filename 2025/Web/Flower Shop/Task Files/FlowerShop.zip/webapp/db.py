import sqlite3

DATABASE = "flowershop.db"

# Function to create conection to database and return conn and cursor
def connect_db():
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        return conn, c
    
    except Exception as error:
        print(f"\n[!] Error Connecting To Database.\n[!] {error}\n")
        return None, None

# Function to check a given username and password against the db when logging in
def check_creds(data):
    where_clause = " AND ".join([f"{key}='{value}'" for key, value in data.items()])
    query = f"SELECT email FROM Users WHERE {where_clause} LIMIT 1"

    conn, c = connect_db()

    c.execute(query)
    exists = c.fetchone()
    conn.close()
    
    return exists