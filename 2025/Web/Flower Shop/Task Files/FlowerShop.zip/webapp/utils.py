from flask import session, abort
from functools import wraps

def is_admin(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'email' not in session or session.get('email') != 'admin@flowershop.p2p':
            abort(403)
        return f(*args, **kwargs)
    return decorated_function
