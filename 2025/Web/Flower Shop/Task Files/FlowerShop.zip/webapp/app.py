from flask import Flask, request, session, render_template, redirect, url_for
from db import check_creds
from utils import is_admin
from hashlib import sha1
from os import urandom
import re

app = Flask(__name__, template_folder="templates", static_folder="static")

app.secret_key = "19ec01f140def0415137134f4b2a2ee3130950202adf2765c17804ed16e310af"

@app.route("/", methods=["GET", "POST"])
def index():
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error="")
    
    else:
        creds = {}

        if "email" in request.form:
            if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9]{2,}$', request.form["email"]):
                creds["email"] = request.form["email"]
            else:
                return render_template("login.html", error="Invalid Email or Password")

        if "password" in request.form:
            creds["password"] = sha1(request.form["password"].encode()).hexdigest()

        if creds == {}:
            return render_template("login.html", error="You must supply an Email and Password")

        if not check_creds(creds):
            return render_template("login.html", error="Invalid Email or Password")

        else:
            session["email"] = request.form["email"]
            return redirect(url_for("admin"))

@app.route("/admin", methods=["GET"])
@is_admin
def admin():
    return render_template("admin.html")

# Error Handling Routes
@app.errorhandler(405)
def method_not_allowed(error):
    return render_template("error.html", error_code="405", error_message="Method Not Allowed"), 405

@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", error_code="404", error_message="Page Could Not Be Found"), 404

@app.errorhandler(403)
def forbidden(error):
    return render_template("error.html", error_code="403", error_message="Access Forbidden"), 403

@app.errorhandler(400)
def bad_request(error):
    return render_template("error.html", error_code="400", error_message="Bad Request"), 400

@app.errorhandler(500)
def internal_error(error):
    return render_template("error.html", error_code="500", error_message="Internal Server Error"), 500

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=80)
