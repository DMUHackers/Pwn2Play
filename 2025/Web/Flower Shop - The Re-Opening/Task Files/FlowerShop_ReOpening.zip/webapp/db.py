from hashlib import sha1
import sqlite3

DATABASE = "flowershop.db"

# Function to create conection to database and return conn and cursor
def connect_db():
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        return conn, c
    
    except Exception as error:
        print(f"\n[!] Error Connecting To Database.\n[!] {error}\n")
        return None, None

# Function to check given credentials against the database
def check_creds(email, password):
    query = "SELECT email, password FROM users WHERE email = ?"

    # Hash the password
    hashed_password = sha1(password.encode()).hexdigest()

    # Connect to db
    conn, c = connect_db()

    # Run the query
    c.execute(query, (email,))
    row = c.fetchone()
    # Close connection to db
    conn.close()

    if row is None:
        # User does not exist, return False
        return False

    # Get stored hashed password
    stored_password = row[1]

    # Check generated hashed password against stored one
    if hashed_password == stored_password:
        return True
    else:
        # Incorrect password   
        return False

# Function to get all flowers to display on index page
def get_flowers():
    query = "SELECT name, price, imagePath FROM flowers"

    conn, c = connect_db()

    flower_data = c.execute(query).fetchall()
    conn.close()

    return flower_data

# Function to check given search query against list of blacklisted words
def check_blacklisted(search):
    blacklisted_words = ["select", "SELECT", "from", "FROM", "where", "WHERE",
                 "or", "OR", "and", "AND", "union", "UNION",
                 "all", "ALL", "users", "USERS"]

    for word in blacklisted_words:
        if word in search.split(" "):
            return True
        else:
            pass
    return False

# Function to search flowers using a given search
def flower_search(search):
    query = "SELECT name, price, imagePath FROM flowers WHERE name LIKE '%{}%'"

    # Check if any blacklisted words are in the search query
    if check_blacklisted(search):
        return []

    conn, c = connect_db()

    try:
        flower_data = c.execute(query.format(search)).fetchall()
        conn.close()
    except Exception:
        return []
    
    return flower_data
