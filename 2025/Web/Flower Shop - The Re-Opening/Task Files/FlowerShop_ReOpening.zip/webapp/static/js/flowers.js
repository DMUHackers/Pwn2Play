var main_body = document.getElementById('index-body')
var container = document.getElementById('flower-container');

if (flowers.length === 0) {
    var flower = `
    <div class="center-content">
        <h2>No Flowers to Show</h2>
    </div>`;
    main_body.innerHTML += flower;
} else {
    flowers.forEach(flower => {
        var flowerHtml = `
        <div class="flower">
            <img src="/static/images/${flower[2]}" alt="${flower[0]}">
            <h2>${flower[0]}</h2>
            <p>$${flower[1]}</p>
            <button>Add to Cart</button>
        </div>`;
        container.innerHTML += flowerHtml;
    });
}