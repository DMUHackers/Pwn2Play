from flask import Flask, request, session, render_template, redirect, url_for
from db import check_creds, get_flowers, flower_search
from utils import is_admin
from os import urandom

app = Flask(__name__, template_folder="templates", static_folder="static")

app.secret_key = "5025644f255f33e6513b241e99d05262d1f6ba96b457ea1eed8ce7dc9a943012"

# Index page route
@app.route("/", methods=["GET", "POST"])
def index():
    # Get flower data from db
    flower_data = get_flowers()
    
    if request.method == "GET":
        return render_template("index.html", flowers=flower_data)

    else:
        if "search" in request.form:
            search_query = request.form["search"]

        else:
            # If a POST request is made but no search parameter given, return normal index page
            return redirect(request.url)

        # If no search query is provided, return the standard index page
        if not search_query:
            return redirect(request.url)

        # Select data from db LIKE search_query
        flower_data = flower_search(search_query)
        return render_template("index.html", flowers=flower_data)

# Login page route
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error="")
    
    else:
        email = request.form["email"]
        password = request.form["password"]

        # Check if both email and password are supplied
        if not email or not password:
            return render_template("login.html", error="You must supply an email and password")

        # Check credentials against db
        if not check_creds(email, password):
            return render_template("login.html", error="Invalid Email or Password")

        else:
            session["email"] = email
            return redirect(url_for("admin"))

# Admin page route
@app.route("/admin", methods=["GET"])
@is_admin
def admin():
    return render_template("admin.html")

# Error Handling Routes
@app.errorhandler(405)
def method_not_allowed(error):
    return render_template("error.html", error_code="405", error_message="Method Not Allowed"), 405

@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", error_code="404", error_message="Page Could Not Be Found"), 404

@app.errorhandler(403)
def forbidden(error):
    return render_template("error.html", error_code="403", error_message="Access Forbidden"), 403

@app.errorhandler(400)
def bad_request(error):
    return render_template("error.html", error_code="400", error_message="Bad Request"), 400

@app.errorhandler(500)
def internal_error(error):
    return render_template("error.html", error_code="500", error_message="Internal Server Error"), 500

# admin@flowershop.dmuh : 3fb02f5916ca73ae2d95e9d45d7bffaf62bd9b42

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=80)
