from flask import Flask, session, render_template, abort, redirect, url_for, request, send_from_directory
import os
from werkzeug.utils import secure_filename
import copy

app = Flask(__name__)
app.secret_key = "dba25d6d26c0d51a89e5735888c0167e"

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf'}

THUMBNAIL_FOLDER = 'static/thumbnails'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(THUMBNAIL_FOLDER, exist_ok=True)

def allowed_extension(filename):
    return "." in filename and filename.split(".")[1] == "pdf"

message_board_posts = [
    {
        "title": "Best Vegetables for a Small Garden?",
        "author": "GreenThumb42",
        "content": "I'm trying to start a small raised bed garden on my patio. What are the easiest and most productive vegetables for beginners?",
        "topic": "gardening"
    },
    {
        "title": "How Often Should I Water My Tomatoes?",
        "author": "PlantLover21",
        "content": "I’m growing tomatoes for the first time and I’m not sure how often to water them. Any tips would be appreciated!",
        "topic": "gardening"
    },
    {
        "title": "DIY Pallet Coffee Table Project",
        "author": "CraftyCarl",
        "content": "Just finished building a rustic coffee table out of an old pallet. Took a few hours, but it looks amazing! Happy to share plans if anyone’s interested.",
        "topic": "diy"
    },
    {
        "title": "Easy Weekend DIY for Beginners?",
        "author": "NewBuilder",
        "content": "I'm looking for a simple weekend project to get started with DIY. Preferably something that doesn't require too many tools.",
        "topic": "diy"
    },
    {
        "title": "Fixing a Leaky Faucet",
        "author": "FixItFrank",
        "content": "My kitchen faucet started leaking yesterday. Is this something I can fix myself, or should I call a plumber?",
        "topic": "home-repair"
    },
    {
        "title": "Best Tools for Basic Home Repairs?",
        "author": "HandyHannah",
        "content": "I just moved into my first home and want to build a basic tool kit for repairs. What tools do you consider must-haves?",
        "topic": "home-repair"
    },
    {
        "title": "Paint Colors for a Small Living Room",
        "author": "DesignDiva99",
        "content": "I want to make my small living room look bigger and brighter. What paint colors have worked for you?",
        "topic": "interior-design"
    },
    {
        "title": "Gallery Wall Layout Help",
        "author": "ArtFan88",
        "content": "I’m trying to create a gallery wall in my hallway but struggling with the layout. Does anyone have tips or templates they like?",
        "topic": "interior-design"
    }
]

original_message_board_posts = copy.deepcopy(message_board_posts)

@app.route("/")
def index():
    session["admin"] = False
    return redirect(url_for("forum", topic="gardening"))


@app.route('/forum/<topic>')
def forum(topic):
    global message_board_posts
    allowed_topics = ['gardening', 'diy', 'home-repair', 'interior-design']
    
    if topic not in allowed_topics:
        abort(404)

    if len(os.listdir("/app/static/uploads")) >= 10:
        os.system("rm /app/static/uploads/*")
        os.system("rm /app/static/thumbnails/*")
        message_board_posts = copy.deepcopy(original_message_board_posts)

    filtered_posts = [post for post in message_board_posts if post["topic"] == topic]

    return render_template('forum.html', topic=topic, posts=filtered_posts)

@app.route('/forum/<topic>/new', methods=["GET", "POST"])
def new_post(topic):
    allowed_topics = ['gardening', 'diy', 'home-repair', 'interior-design']
    if topic not in allowed_topics:
        abort(404)
    
    if request.method == "POST":
        title = request.form.get("title")
        author = request.form.get("author")
        content = request.form.get("content")
        file = request.files.get("attachment")

        attachment_url = None

        if file and allowed_extension(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)
            attachment_filename = filename
        else:
            attachment_filename = None
        message_board_posts.append({
            "title": title,
            "author": author,
            "content": content,
            "topic": topic,
            "attachment": attachment_filename
        })


        return redirect(url_for('forum', topic=topic))
    return render_template('new_post.html', topic=topic)


@app.route("/view_pdf/<filename>")
def view_pdf(filename):
    if not allowed_extension(filename):
        abort(403)
    
    pdf_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    thumb_filename = f"{os.path.splitext(filename)[0]}.jpeg"
    thumb_path = os.path.join(THUMBNAIL_FOLDER, thumb_filename)

    if not os.path.exists(thumb_path):
        cmd = f"sudo -u ghost gs -dNOPAUSE -dBATCH -dSAFER -sDEVICE=jpeg -r150 -dFirstPage=1 -dLastPage=1 -sOutputFile='{thumb_path}' '{pdf_path}'"

        os.system(cmd)

        for i, post in enumerate(message_board_posts):
            if post.get("attachment_filename") == filename:
                message_board_posts.pop(i)
                break
        
        return render_template("view_pdf.html", thumb_file=url_for('static', filename=f"thumbnails/{thumb_filename}"), pdf_file=filename)
    



@app.errorhandler(403)
def forbidden():
    return render_template("403.html"), 403

@app.errorhandler(404)
def not_found(err):
    return render_template("404.html"), 404

@app.errorhandler(401)
def unauthorised(err):
    return render_template("401.html"), 401

@app.route("/get_flag")
def get_flag():
    if not session["admin"]:
        abort(401)
    with open("flag.txt", "r") as flag:
        return flag.read()

