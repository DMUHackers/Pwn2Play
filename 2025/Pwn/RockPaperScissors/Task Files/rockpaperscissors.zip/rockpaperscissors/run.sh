#!/bin/bash
# run.sh

# while true; do
# 	export SEED=$(od -vAn -N4 -tu4 < /dev/urandom)
#     exec socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"./predictable_rps",pty,stderr
#     sleep 1
# done

SEED=$(od -vAn -N4 -tu4 < /dev/urandom | tr -d ' ')
export SEED
exec ./predictable_rps