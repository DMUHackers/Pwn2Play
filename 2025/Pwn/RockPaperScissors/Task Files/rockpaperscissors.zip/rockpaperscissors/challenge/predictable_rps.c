#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NAME_SIZE 64

const char *moves[] = {"rock", "paper", "scissors"};

int get_winner(const char *player_move, const char *cpu_move) {
    if (strcmp(player_move, cpu_move) == 0)
        return 0; // tie
    if ((strcmp(player_move, "rock") == 0 && strcmp(cpu_move, "scissors") == 0) ||
        (strcmp(player_move, "paper") == 0 && strcmp(cpu_move, "rock") == 0) ||
        (strcmp(player_move, "scissors") == 0 && strcmp(cpu_move, "paper") == 0))
        return 1; // win
    return -1; // lose
}

int main() {

    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    char name[NAME_SIZE];
    char player_move[16];
    char message[128];
    int win_streak = 0;
    int total_losses = 0;

    const char *seed_str = getenv("SEED");
    if (!seed_str) {
        fprintf(stderr, "Missing SEED environment variable.\n");
        return 1;
    }

    unsigned long seed = strtoul(seed_str, NULL, 10);
    srand(seed);


    printf("What is your name: ");
    fgets(name, NAME_SIZE, stdin);
    name[strcspn(name, "\n")] = 0;

    printf("Welcome %s\n", name);

    while (win_streak < 100) {
        int cpu_choice = rand() % 3;
        const char *cpu_move = moves[cpu_choice];

        printf("Your move (rock/paper/scissors): ");
        if (!fgets(player_move, sizeof(player_move), stdin)) break;
        player_move[strcspn(player_move, "\n")] = 0;

        int result = get_winner(player_move, cpu_move);
        if (result == 1) {
            win_streak++;
            printf("You win! Streak: %d\n", win_streak);
        } else if (result == 0) {
            printf("Tie! Streak reset.\n");
            win_streak = 0;
        } else {
            printf("You lose! Streak reset.\n");
            win_streak = 0;
            total_losses++;
        }
        if(total_losses >= 15) {
            snprintf(message, sizeof(message), "Oh dear %s, you're not very good at this game!\n", name);
            printf(message);
            total_losses = 0;
        }
    }

    if (win_streak == 100) {
        FILE *fp = fopen("flag.txt", "r");
        if (fp) {
            char flag[128];
            fgets(flag, sizeof(flag), fp);
            printf("Congratulations! Here is your flag: %s\n", flag);
            fclose(fp);
        } else {
            printf("Flag file not found!\n");
        }
    }

    return 0;
}
