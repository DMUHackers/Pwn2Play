#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define USERNAME_LENGTH 12
#define MESSAGE_LENGTH 64
#define RATING_LENGTH 32

typedef struct user{
	char name[USERNAME_LENGTH];
	char message[MESSAGE_LENGTH];
} user_t;

void banner(){
    puts("Welcome to LetsChat!\n");
    puts("(We are still in beta testing so you can only create 1 user for the time being...)");
}

void menu(){
    printf("\n1) Create User\n2) Send Message\n3) Exit\n99) Leave Rating\n>> ");
}

int chat(){
    user_t users[1];
    char rating[RATING_LENGTH];
    int created_users = 0;

    while (true){
        int choice = 0;
        menu();

        if (scanf("%d", &choice) != 1) exit(0);
		getchar();

        if (choice == 1){
            if (created_users >= 1){
                puts("You can only create 1 user!");
                continue;
            }

            printf("\nUsername: ");
            fflush(stdin);
            fgets(users[created_users].name, USERNAME_LENGTH, stdin);
            created_users++;
            puts("User created!");
        }

        else if (choice == 2){
            if (created_users == 0){
                puts("No users to send a message to...");
                continue;
            }

            printf("\nMessage: ");
            fgets(users[created_users].message, MESSAGE_LENGTH, stdin);
            puts("Message sent!");
        }

        else if (choice == 3){
            puts("\nExiting...");
            return 0;
        }

        else if (choice == 99){
            printf("\nEnter Rating Here (eg. '5 Stars'): ");
            fgets(rating, 256, stdin);
            puts("Thank you for your support!");
            return 0;
        }

        else {
            puts("\nInvalid Choice.");
        }

    }

    return 0;
}

void my_random_strings(){
    static char a[] = "My Selection of Random Strings";
    static char b[] = "I LOVE random strings";
    static char c[] = "/bin/sh";
    static char d[] = "One stringy boy";
    static char e[] = "mmmmmmm strings";
    static char f[] = "cat";
    static char g[] = "/bin";
    static char h[] = "I use Arch btw";
}

void why_is_this_even_here(){
    system("ls");
}

int main(){
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    banner();

    chat();
    return 0;
}
