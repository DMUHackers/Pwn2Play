#include <stdio.h>
#include <stdlib.h>

static short meridiasBeacon = 0;
static char thuum[] = {
	0x65, 0x04, 0x70, 0x50,
	0x36, 0x5a, 0x3b, 0x5c,
	0x72, 0x06, 0x7e, 0x0a,
	0x00
};
static char playerInventory[][40] = {
	"Dwarven Sword",
	"2x Potion Of Minor Healing",
	"11x Skoomer",
	"5x Nirnroot",
	"Sweet Roll",
	"The Lusty Argonian Maid Vol 1",
	"Goat Cheese Wheel",
};

void touchBeacon()
{
	puts("+ Meridia's Beacon");
	meridiasBeacon = 1;
	puts("\033[1;34mA new hand touches the beacon...\033[0m");
}

void learnShout()
{
	unsigned char elderScrolls = 0x06;
	unsigned char previousByte = elderScrolls;
	for (int i = 0; i < 13; ++i)
	{
		unsigned char currentByte = thuum[i];
		thuum[i] ^= previousByte;
		previousByte = currentByte;
	}
}

void vanquishMalkoran()
{
	if (!meridiasBeacon)
	{
		puts("To enter this dungeon you must \033[1;31mtouch the beacon\033[0m.\n");
		return;
	}
	printf("Casting> %s\n", thuum);
	system(thuum);
}

void printInventory()
{
	puts("Adventurer's Inventory:");
	for (int i = 0; i < 7; ++i)
		printf("\033[1;33m|%s|\033[0m ", playerInventory[i]);
}

void getPlayerAction()
{
	puts("\n\n*Opens Chest* (loot all y/n)");
	char buffer[40];
	gets(buffer);
	if (*buffer == 'y')
	{
		puts("\n+ 50 gold");
		puts("+ Bowl (Wooden)");
		touchBeacon();
	}
	else if (*buffer == 'n')
	{
		puts("\nYou never should have come here... Maybe I should go back to the College of Winterhold and \033[1;31mdisassemble\033[0m this 32-bit tome.\n");
	}
}

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	puts("Hey, you. You're finally awake...\n");
	printInventory();
	getPlayerAction();
	return 0;
}
